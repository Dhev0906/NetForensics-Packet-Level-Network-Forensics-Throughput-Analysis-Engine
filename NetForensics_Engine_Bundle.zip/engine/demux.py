"""
Demultiplexing & Session Reconstruction Module
Groups raw packet records into bidirectional 5-tuple conversation flows (Sessions).
Tracks TCP state machines, initiator/responder roles, and conversation metadata.
"""

from typing import List, Dict, Tuple, Optional, Any
from enum import Enum
from .parser import PacketRecord


class FlowDirection(str, Enum):
    FORWARD = "fwd"    # Client -> Server (Initiator to Responder)
    REVERSE = "rev"    # Server -> Client (Responder to Initiator)
    UNKNOWN = "unk"


class TCPState(str, Enum):
    NEW = "NEW"
    SYN_SENT = "SYN_SENT"
    SYN_RECEIVED = "SYN_RECEIVED"
    ESTABLISHED = "ESTABLISHED"
    FIN_WAIT = "FIN_WAIT"
    CLOSED = "CLOSED"
    RESET = "RESET"
    NON_TCP = "N/A"


class ConversationSession:
    """Represents a bidirectional conversation session between two endpoints."""

    def __init__(self, session_id: str, client_ip: str, client_port: int,
                 server_ip: str, server_port: int, proto: str):
        self.session_id: str = session_id
        self.client_ip: str = client_ip
        self.client_port: int = client_port
        self.server_ip: str = server_ip
        self.server_port: int = server_port
        self.proto: str = proto
        self.app_proto: str = proto

        self.packets: List[PacketRecord] = []
        self.fwd_packets: List[PacketRecord] = []
        self.rev_packets: List[PacketRecord] = []

        # Timestamps
        self.start_time: float = 0.0
        self.end_time: float = 0.0
        self.duration: float = 0.0

        # Wire & Payload Metrics
        self.total_wire_bytes: int = 0
        self.fwd_wire_bytes: int = 0
        self.rev_wire_bytes: int = 0

        self.total_payload_bytes: int = 0
        self.fwd_payload_bytes: int = 0
        self.rev_payload_bytes: int = 0

        # TCP Connection State
        self.tcp_state: TCPState = TCPState.NON_TCP if proto != "TCP" else TCPState.NEW
        self.syn_time: Optional[float] = None
        self.syn_ack_time: Optional[float] = None
        self.handshake_ack_time: Optional[float] = None
        self.handshake_rtt: Optional[float] = None

        # Window scaling
        self.client_win_scale: int = 0
        self.server_win_scale: int = 0
        self.client_mss: Optional[int] = None
        self.server_mss: Optional[int] = None

        # Tags & Anomalies
        self.is_truncated: bool = False
        self.has_reset: bool = False
        self.has_zero_window: bool = False

    @property
    def packet_count(self) -> int:
        return len(self.packets)

    @property
    def fwd_packet_count(self) -> int:
        return len(self.fwd_packets)

    @property
    def rev_packet_count(self) -> int:
        return len(self.rev_packets)

    @property
    def client_endpoint(self) -> str:
        return f"{self.client_ip}:{self.client_port}"

    @property
    def server_endpoint(self) -> str:
        return f"{self.server_ip}:{self.server_port}"

    @property
    def title(self) -> str:
        return f"{self.client_endpoint} ⇄ {self.server_endpoint} ({self.proto})"

    def add_packet(self, pkt: PacketRecord, is_fwd: bool) -> None:
        """Appends packet to the session, updating state and byte counters."""
        if not self.packets:
            self.start_time = pkt.timestamp
            if pkt.app_proto and pkt.app_proto not in ("TCP", "UDP"):
                self.app_proto = pkt.app_proto

        self.end_time = pkt.timestamp
        self.duration = max(0.000001, self.end_time - self.start_time)
        self.packets.append(pkt)
        pkt.session_id = self.session_id
        pkt.direction = "fwd" if is_fwd else "rev"

        if pkt.app_proto and self.app_proto in ("TCP", "UDP") and pkt.app_proto not in ("TCP", "UDP"):
            self.app_proto = pkt.app_proto

        wire_b = pkt.wire_len
        payload_b = pkt.payload_len
        self.total_wire_bytes += wire_b
        self.total_payload_bytes += payload_b

        if is_fwd:
            self.fwd_packets.append(pkt)
            self.fwd_wire_bytes += wire_b
            self.fwd_payload_bytes += payload_b
        else:
            self.rev_packets.append(pkt)
            self.rev_wire_bytes += wire_b
            self.rev_payload_bytes += payload_b

        # TCP State Tracking
        if self.proto == "TCP":
            self._update_tcp_state(pkt, is_fwd)

    def _update_tcp_state(self, pkt: PacketRecord, is_fwd: bool) -> None:
        flags = pkt.tcp_flags

        if flags.get("RST"):
            self.has_reset = True
            self.tcp_state = TCPState.RESET

        # Handshake sequence: SYN -> SYN+ACK -> ACK
        if is_fwd and flags.get("SYN") and not flags.get("ACK"):
            self.tcp_state = TCPState.SYN_SENT
            self.syn_time = pkt.timestamp
            if pkt.tcp_win_scale is not None:
                self.client_win_scale = pkt.tcp_win_scale
            if pkt.tcp_mss is not None:
                self.client_mss = pkt.tcp_mss

        elif not is_fwd and flags.get("SYN") and flags.get("ACK"):
            self.tcp_state = TCPState.SYN_RECEIVED
            self.syn_ack_time = pkt.timestamp
            if pkt.tcp_win_scale is not None:
                self.server_win_scale = pkt.tcp_win_scale
            if pkt.tcp_mss is not None:
                self.server_mss = pkt.tcp_mss

            if self.syn_time is not None:
                self.handshake_rtt = max(0.0, self.syn_ack_time - self.syn_time)

        elif is_fwd and flags.get("ACK") and not flags.get("SYN") and self.tcp_state == TCPState.SYN_RECEIVED:
            self.tcp_state = TCPState.ESTABLISHED
            self.handshake_ack_time = pkt.timestamp

        elif flags.get("FIN"):
            if self.tcp_state == TCPState.ESTABLISHED:
                self.tcp_state = TCPState.FIN_WAIT
            elif self.tcp_state == TCPState.FIN_WAIT:
                self.tcp_state = TCPState.CLOSED

        if pkt.tcp_win == 0 and not flags.get("RST") and not flags.get("SYN"):
            self.has_zero_window = True

    def to_summary_dict(self) -> Dict[str, Any]:
        """Convert session to summary dictionary for dashboard lists."""
        wire_mbps = (self.total_wire_bytes * 8) / (self.duration * 1e6) if self.duration > 0 else 0.0
        goodput_mbps = (self.total_payload_bytes * 8) / (self.duration * 1e6) if self.duration > 0 else 0.0

        return {
            "session_id": self.session_id,
            "title": self.title,
            "client_ip": self.client_ip,
            "client_port": self.client_port,
            "server_ip": self.server_ip,
            "server_port": self.server_port,
            "proto": self.proto,
            "app_proto": self.app_proto,
            "packet_count": self.packet_count,
            "fwd_packets": self.fwd_packet_count,
            "rev_packets": self.rev_packet_count,
            "total_wire_bytes": self.total_wire_bytes,
            "total_payload_bytes": self.total_payload_bytes,
            "duration_sec": round(self.duration, 4),
            "start_time": self.start_time,
            "end_time": self.end_time,
            "wire_mbps": round(wire_mbps, 3),
            "goodput_mbps": round(goodput_mbps, 3),
            "tcp_state": self.tcp_state.value,
            "handshake_rtt_ms": round(self.handshake_rtt * 1000, 2) if self.handshake_rtt is not None else None,
            "has_reset": self.has_reset,
            "has_zero_window": self.has_zero_window,
        }


class SessionDemuxer:
    """Demultiplexes flat packet list into distinct bidirectional Sessions."""

    def __init__(self):
        pass

    def demux(self, packets: List[PacketRecord]) -> Dict[str, ConversationSession]:
        """Groups packets into 5-tuple conversations and returns session map."""
        sessions: Dict[str, ConversationSession] = {}
        # Mapping 5-tuple keys to session_id
        tuple_map: Dict[Tuple[str, str, int, int, str], str] = {}
        session_counter = 1

        for pkt in packets:
            # Handle non-IP packets (e.g. pure ARP or L2)
            if not pkt.src_ip or not pkt.dst_ip:
                key = (pkt.src_mac or "00", pkt.dst_mac or "00", 0, 0, pkt.network_proto or "L2")
            else:
                key = pkt.conversation_key

            if key not in tuple_map:
                # Determine Client (Initiator) vs Server
                # If TCP SYN packet (without ACK), this endpoint is definitely Client
                is_fwd = True
                if pkt.transport_proto == "TCP":
                    if pkt.tcp_flags.get("SYN") and not pkt.tcp_flags.get("ACK"):
                        client_ip, client_port = pkt.src_ip, pkt.src_port
                        server_ip, server_port = pkt.dst_ip, pkt.dst_port
                    elif pkt.tcp_flags.get("SYN") and pkt.tcp_flags.get("ACK"):
                        client_ip, client_port = pkt.dst_ip, pkt.dst_port
                        server_ip, server_port = pkt.src_ip, pkt.src_port
                        is_fwd = False
                    else:
                        client_ip, client_port = pkt.src_ip, pkt.src_port
                        server_ip, server_port = pkt.dst_ip, pkt.dst_port
                else:
                    client_ip, client_port = pkt.src_ip, pkt.src_port
                    server_ip, server_port = pkt.dst_ip, pkt.dst_port

                sess_id = f"flow_{session_counter:03d}_{client_ip}_{client_port}_to_{server_ip}_{server_port}_{pkt.transport_proto or pkt.network_proto}"
                session_counter += 1

                session = ConversationSession(
                    session_id=sess_id,
                    client_ip=client_ip,
                    client_port=client_port,
                    server_ip=server_ip,
                    server_port=server_port,
                    proto=pkt.transport_proto or pkt.network_proto or "OTHER"
                )
                sessions[sess_id] = session
                tuple_map[key] = sess_id
                session.add_packet(pkt, is_fwd=is_fwd)
            else:
                sess_id = tuple_map[key]
                session = sessions[sess_id]
                is_fwd = (pkt.src_ip == session.client_ip and pkt.src_port == session.client_port)
                session.add_packet(pkt, is_fwd=is_fwd)

        return sessions
