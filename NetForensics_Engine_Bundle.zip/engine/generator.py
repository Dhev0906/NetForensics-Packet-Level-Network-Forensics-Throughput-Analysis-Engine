"""
Synthetic PCAP Scenario Generator
Generates realistic, mathematically accurate network packet traces for testing and demonstration.
Scenarios:
 1. Clean Gigabit High-Speed Transfer
 2. Router Packet Loss (Queue Drops, Dup ACKs, Fast Retransmits)
 3. High Latency Satellite Link (Propagation Delay & BDP limit)
 4. Severe Bufferbloat Bottleneck (Queue delay swelling)
 5. Receiver Zero-Window Throttling (Socket buffer starvation)
 6. Multi-Flow Enterprise Traffic (DNS, HTTP, TLS, ICMP)
"""

import struct
import socket
import os
import random
from typing import List, Tuple, Optional


class PcapWriter:
    """Writes standard Ethernet PCAP files."""

    def __init__(self, filepath: str):
        self.filepath = filepath
        self.f = open(filepath, "wb")
        # Global Header: magic_number (0xa1b2c3d4), version_major (2), version_minor (4),
        # thiszone (0), sigfigs (0), snaplen (65535), network (1 = Ethernet)
        self.f.write(struct.pack("<IHHiIII", 0xa1b2c3d4, 2, 4, 0, 0, 65535, 1))

    def write_packet(self, ts: float, raw_data: bytes):
        sec = int(ts)
        usec = int((ts - sec) * 1e6)
        caplen = len(raw_data)
        wirelen = len(raw_data)
        self.f.write(struct.pack("<IIII", sec, usec, caplen, wirelen))
        self.f.write(raw_data)

    def close(self):
        if self.f:
            self.f.close()
            self.f = None


def make_ipv4_header(src_ip: str, dst_ip: str, proto: int, payload_len: int, ip_id: int = 100, ttl: int = 64) -> bytes:
    ver_ihl = (4 << 4) | 5
    tos = 0
    total_len = 20 + payload_len
    flags_frag = 0x4000  # DF set
    checksum = 0
    src_bytes = socket.inet_aton(src_ip)
    dst_bytes = socket.inet_aton(dst_ip)
    header_no_chk = struct.pack("!BBHHHBBH4s4s", ver_ihl, tos, total_len, ip_id, flags_frag, ttl, proto, 0, src_bytes, dst_bytes)

    # Compute IP checksum
    chk = 0
    for i in range(0, 20, 2):
        chk += (header_no_chk[i] << 8) + header_no_chk[i + 1]
    while chk >> 16:
        chk = (chk & 0xFFFF) + (chk >> 16)
    chk = (~chk) & 0xFFFF

    return struct.pack("!BBHHHBBH4s4s", ver_ihl, tos, total_len, ip_id, flags_frag, ttl, proto, chk, src_bytes, dst_bytes)


def make_tcp_segment(src_ip: str, dst_ip: str, src_port: int, dst_port: int,
                     seq: int, ack: int, flags_dict: dict, win: int = 65535,
                     payload: bytes = b"", options: bytes = b"", ip_id: int = 100) -> bytes:
    eth_hdr = bytes.fromhex("001122334455") + bytes.fromhex("66778899aabb") + struct.pack("!H", 0x0800)

    # Flags byte
    f_byte = 0
    if flags_dict.get("FIN"): f_byte |= 0x01
    if flags_dict.get("SYN"): f_byte |= 0x02
    if flags_dict.get("RST"): f_byte |= 0x04
    if flags_dict.get("PSH"): f_byte |= 0x08
    if flags_dict.get("ACK"): f_byte |= 0x10
    if flags_dict.get("URG"): f_byte |= 0x20

    # Padding options to multiple of 4 bytes
    if len(options) % 4 != 0:
        options += b"\x01" * (4 - (len(options) % 4))  # NOP padding

    data_offset = (20 + len(options)) // 4
    data_offset_byte = (data_offset << 4)

    tcp_hdr = struct.pack("!HHIIBBHHH", src_port, dst_port, seq, ack, data_offset_byte, f_byte, win, 0, 0) + options
    ip_hdr = make_ipv4_header(src_ip, dst_ip, 6, len(tcp_hdr) + len(payload), ip_id=ip_id)

    return eth_hdr + ip_hdr + tcp_hdr + payload


def make_udp_packet(src_ip: str, dst_ip: str, src_port: int, dst_port: int,
                    payload: bytes = b"", ip_id: int = 200) -> bytes:
    eth_hdr = bytes.fromhex("001122334455") + bytes.fromhex("66778899aabb") + struct.pack("!H", 0x0800)
    udp_len = 8 + len(payload)
    udp_hdr = struct.pack("!HHHH", src_port, dst_port, udp_len, 0)
    ip_hdr = make_ipv4_header(src_ip, dst_ip, 17, udp_len, ip_id=ip_id)
    return eth_hdr + ip_hdr + udp_hdr + payload


def make_icmp_packet(src_ip: str, dst_ip: str, icmp_type: int = 8, icmp_code: int = 0,
                     seq_num: int = 1, ip_id: int = 300) -> bytes:
    eth_hdr = bytes.fromhex("001122334455") + bytes.fromhex("66778899aabb") + struct.pack("!H", 0x0800)
    icmp_payload = struct.pack("!HH", 0x1234, seq_num) + b"NETFORENSICS_ECHO_PAYLOAD_TESTING"
    icmp_hdr = struct.pack("!BBH", icmp_type, icmp_code, 0) + icmp_payload
    ip_hdr = make_ipv4_header(src_ip, dst_ip, 1, len(icmp_hdr), ip_id=ip_id)
    return eth_hdr + ip_hdr + icmp_hdr


class ScenarioGenerator:
    """Builds synthetic pcap files with specific forensic conditions."""

    @staticmethod
    def generate_clean_gigabit(filepath: str, num_packets: int = 150) -> str:
        """Generates healthy high-speed TCP stream."""
        pcap = PcapWriter(filepath)
        t = 1710000000.0
        client_ip = "192.168.1.100"
        server_ip = "10.0.0.50"
        client_port = 52140
        server_port = 443

        # Handshake (RTT = 2ms)
        # 1. SYN
        wscale_opt = b"\x03\x03\x07"  # WScale = 7 (x128)
        mss_opt = b"\x02\x04\x05\xb4"  # MSS = 1460
        pcap.write_packet(t, make_tcp_segment(client_ip, server_ip, client_port, server_port, 1000, 0, {"SYN": True}, win=65535, options=mss_opt + wscale_opt, ip_id=1))

        # 2. SYN-ACK (2ms later)
        t += 0.002
        pcap.write_packet(t, make_tcp_segment(server_ip, client_ip, server_port, client_port, 5000, 1001, {"SYN": True, "ACK": True}, win=65535, options=mss_opt + wscale_opt, ip_id=2))

        # 3. ACK (2ms later)
        t += 0.002
        pcap.write_packet(t, make_tcp_segment(client_ip, server_ip, client_port, server_port, 1001, 5001, {"ACK": True}, win=65535, ip_id=3))

        # High speed data flow
        client_seq = 1001
        server_ack = 1001
        mss = 1460
        payload_block = b"X" * mss

        for i in range(num_packets):
            t += 0.0003  # High frequency burst
            # Client sends data
            pcap.write_packet(t, make_tcp_segment(client_ip, server_ip, client_port, server_port, client_seq, 5001, {"ACK": True, "PSH": True}, win=65535, payload=payload_block, ip_id=10 + i))
            client_seq += mss

            # Server ACKs every 2 packets (Delayed ACK standard)
            if i % 2 == 1:
                t += 0.002  # 2ms RTT
                server_ack = client_seq
                pcap.write_packet(t, make_tcp_segment(server_ip, client_ip, server_port, client_port, 5001, server_ack, {"ACK": True}, win=65535, ip_id=1000 + i))

        # Teardown
        t += 0.005
        pcap.write_packet(t, make_tcp_segment(client_ip, server_ip, client_port, server_port, client_seq, server_ack, {"FIN": True, "ACK": True}, ip_id=9000))
        t += 0.002
        pcap.write_packet(t, make_tcp_segment(server_ip, client_ip, server_port, client_port, 5001, client_seq + 1, {"ACK": True}, ip_id=9001))
        pcap.write_packet(t + 0.001, make_tcp_segment(server_ip, client_ip, server_port, client_port, 5001, client_seq + 1, {"FIN": True, "ACK": True}, ip_id=9002))
        pcap.write_packet(t + 0.003, make_tcp_segment(client_ip, server_ip, client_port, server_port, client_seq + 1, 5002, {"ACK": True}, ip_id=9003))

        pcap.close()
        return filepath

    @staticmethod
    def generate_packet_loss_drop(filepath: str) -> str:
        """Generates flow with router packet drops, Dup ACKs, Fast Retransmits and Timeout."""
        pcap = PcapWriter(filepath)
        t = 1710000100.0
        client_ip = "192.168.1.105"
        server_ip = "172.16.0.22"
        c_port = 54321
        s_port = 80

        # Handshake (RTT = 15ms)
        pcap.write_packet(t, make_tcp_segment(client_ip, server_ip, c_port, s_port, 100, 0, {"SYN": True}, ip_id=1))
        t += 0.015
        pcap.write_packet(t, make_tcp_segment(server_ip, client_ip, s_port, c_port, 500, 101, {"SYN": True, "ACK": True}, ip_id=2))
        t += 0.015
        pcap.write_packet(t, make_tcp_segment(client_ip, server_ip, c_port, s_port, 101, 501, {"ACK": True}, ip_id=3))

        mss = 1000
        client_seq = 101
        server_ack = 101

        # Send packets 1, 2, 3 normally
        for i in range(3):
            t += 0.005
            pcap.write_packet(t, make_tcp_segment(client_ip, server_ip, c_port, s_port, client_seq, 501, {"ACK": True}, payload=b"A" * mss, ip_id=10 + i))
            client_seq += mss

        t += 0.015
        server_ack = client_seq
        pcap.write_packet(t, make_tcp_segment(server_ip, client_ip, s_port, c_port, 501, server_ack, {"ACK": True}, ip_id=20))

        # NOW: Packet #4 is transmitted by client, but dropped en route by router!
        dropped_seq = client_seq
        pcap.write_packet(t + 0.002, make_tcp_segment(client_ip, server_ip, c_port, s_port, dropped_seq, 501, {"ACK": True}, payload=b"ORIGINAL_PACKET_4" + b"A" * (mss - 17), ip_id=25))
        client_seq += mss

        # Client sends packet #5, #6, #7
        pkt5_seq = client_seq
        pcap.write_packet(t + 0.005, make_tcp_segment(client_ip, server_ip, c_port, s_port, pkt5_seq, 501, {"ACK": True}, payload=b"B" * mss, ip_id=30))
        client_seq += mss

        pkt6_seq = client_seq
        pcap.write_packet(t + 0.008, make_tcp_segment(client_ip, server_ip, c_port, s_port, pkt6_seq, 501, {"ACK": True}, payload=b"C" * mss, ip_id=31))
        client_seq += mss

        pkt7_seq = client_seq
        pcap.write_packet(t + 0.011, make_tcp_segment(client_ip, server_ip, c_port, s_port, pkt7_seq, 501, {"ACK": True}, payload=b"D" * mss, ip_id=32))
        client_seq += mss

        # Server receives #5 -> missing #4 -> sends Duplicate ACK #1 for dropped_seq
        t += 0.020
        pcap.write_packet(t, make_tcp_segment(server_ip, client_ip, s_port, c_port, 501, dropped_seq, {"ACK": True}, ip_id=40))

        # Server receives #6 -> sends Duplicate ACK #2
        t += 0.003
        pcap.write_packet(t, make_tcp_segment(server_ip, client_ip, s_port, c_port, 501, dropped_seq, {"ACK": True}, ip_id=41))

        # Server receives #7 -> sends Duplicate ACK #3 (Triggers Fast Retransmit!)
        t += 0.003
        pcap.write_packet(t, make_tcp_segment(server_ip, client_ip, s_port, c_port, 501, dropped_seq, {"ACK": True}, ip_id=42))

        # Fast Retransmit: Client immediately retransmits dropped packet #4!
        t += 0.015
        pcap.write_packet(t, make_tcp_segment(client_ip, server_ip, c_port, s_port, dropped_seq, 501, {"ACK": True}, payload=b"RETRANS_PACKET_4" + b"A" * (mss - 16), ip_id=50))

        # Server acknowledges up to packet #7!
        t += 0.015
        server_ack = client_seq
        pcap.write_packet(t, make_tcp_segment(server_ip, client_ip, s_port, c_port, 501, server_ack, {"ACK": True}, ip_id=51))

        # Now simulate a Timeout Retransmit (Packet 8 sent, dropped, and retransmitted after RTO)
        t += 0.020
        timeout_seq = client_seq
        pcap.write_packet(t, make_tcp_segment(client_ip, server_ip, c_port, s_port, timeout_seq, 501, {"ACK": True}, payload=b"ORIGINAL_PACKET_8" + b"Z" * (mss - 17), ip_id=55))
        client_seq += mss

        # Sender waits for RTO (e.g. 250ms)
        t += 0.250
        # RTO expires: Client retransmits packet 8!
        pcap.write_packet(t, make_tcp_segment(client_ip, server_ip, c_port, s_port, timeout_seq, 501, {"ACK": True}, payload=b"TIMEOUT_RETRANS_PACKET_8" + b"Z" * (mss - 24), ip_id=60))

        t += 0.015
        pcap.write_packet(t, make_tcp_segment(server_ip, client_ip, s_port, c_port, 501, timeout_seq + mss, {"ACK": True}, ip_id=61))

        pcap.close()
        return filepath

    @staticmethod
    def generate_high_latency_satellite(filepath: str) -> str:
        """Generates geostationary satellite link with 650ms base RTT."""
        pcap = PcapWriter(filepath)
        t = 1710000200.0
        client_ip = "192.168.100.2"
        server_ip = "203.0.113.88"
        c_port = 48800
        s_port = 443

        # Satellite Handshake (Base RTT = 640ms)
        pcap.write_packet(t, make_tcp_segment(client_ip, server_ip, c_port, s_port, 10000, 0, {"SYN": True}, win=32768, ip_id=1))
        t += 0.640  # 640ms satellite round trip
        pcap.write_packet(t, make_tcp_segment(server_ip, client_ip, s_port, c_port, 80000, 10001, {"SYN": True, "ACK": True}, win=32768, ip_id=2))
        t += 0.640
        pcap.write_packet(t, make_tcp_segment(client_ip, server_ip, c_port, s_port, 10001, 80001, {"ACK": True}, win=32768, ip_id=3))

        seq = 10001
        for i in range(20):
            t += 0.010
            pcap.write_packet(t, make_tcp_segment(client_ip, server_ip, c_port, s_port, seq, 80001, {"ACK": True}, payload=b"SATELLITE_DATA_" + b"S" * 1400, ip_id=10 + i))
            seq += 1415

            if i % 4 == 3:
                # ACKs return 640ms later with very low jitter (+/- 2ms)
                ack_t = t + 0.640 + random.uniform(-0.002, 0.002)
                pcap.write_packet(ack_t, make_tcp_segment(server_ip, client_ip, s_port, c_port, 80001, seq, {"ACK": True}, win=32768, ip_id=200 + i))

        pcap.close()
        return filepath

    @staticmethod
    def generate_bufferbloat_queue(filepath: str) -> str:
        """Generates traffic where RTT swells from 15ms to 420ms under queue saturation."""
        pcap = PcapWriter(filepath)
        t = 1710000300.0
        client_ip = "192.168.1.50"
        server_ip = "93.184.216.34"
        c_port = 58210
        s_port = 8080

        # Handshake: clean 15ms RTT
        pcap.write_packet(t, make_tcp_segment(client_ip, server_ip, c_port, s_port, 2000, 0, {"SYN": True}, ip_id=1))
        t += 0.015
        pcap.write_packet(t, make_tcp_segment(server_ip, client_ip, s_port, c_port, 9000, 2001, {"SYN": True, "ACK": True}, ip_id=2))
        t += 0.015
        pcap.write_packet(t, make_tcp_segment(client_ip, server_ip, c_port, s_port, 2001, 9001, {"ACK": True}, ip_id=3))

        seq = 2001
        mss = 1400
        queue_delay = 0.015  # starts at 15ms

        for i in range(40):
            t += 0.004
            pcap.write_packet(t, make_tcp_segment(client_ip, server_ip, c_port, s_port, seq, 9001, {"ACK": True}, payload=b"BLOAT_PAYLOAD" + b"X" * (mss - 13), ip_id=10 + i))
            seq += mss

            # Queue builds up! Delay increases by 10ms each round up to 420ms
            if i < 30:
                queue_delay = min(0.420, queue_delay + 0.012)
            else:
                queue_delay = max(0.015, queue_delay - 0.035)  # Queue drains

            if i % 2 == 1:
                pcap.write_packet(t + queue_delay, make_tcp_segment(server_ip, client_ip, s_port, c_port, 9001, seq, {"ACK": True}, ip_id=300 + i))

        pcap.close()
        return filepath

    @staticmethod
    def generate_zero_window_receiver(filepath: str) -> str:
        """Generates traffic where receiver window closes to 0 (TCP Zero Window)."""
        pcap = PcapWriter(filepath)
        t = 1710000400.0
        client_ip = "192.168.1.90"
        server_ip = "10.10.10.10"
        c_port = 61234
        s_port = 9000

        # Handshake
        pcap.write_packet(t, make_tcp_segment(client_ip, server_ip, c_port, s_port, 100, 0, {"SYN": True}, win=64000, ip_id=1))
        t += 0.005
        pcap.write_packet(t, make_tcp_segment(server_ip, client_ip, s_port, c_port, 500, 101, {"SYN": True, "ACK": True}, win=64000, ip_id=2))
        t += 0.005
        pcap.write_packet(t, make_tcp_segment(client_ip, server_ip, c_port, s_port, 101, 501, {"ACK": True}, win=64000, ip_id=3))

        seq = 101
        mss = 1460

        # Send heavy bursts that fill receiver socket buffer
        for i in range(10):
            t += 0.002
            pcap.write_packet(t, make_tcp_segment(client_ip, server_ip, c_port, s_port, seq, 501, {"ACK": True}, payload=b"DATA" * (mss // 4), ip_id=10 + i))
            seq += mss

        # Server window collapses to 0! (TCP Zero Window)
        t += 0.005
        pcap.write_packet(t, make_tcp_segment(server_ip, client_ip, s_port, c_port, 501, seq, {"ACK": True}, win=0, ip_id=20))

        # Client pauses! After 1.0s, client sends a 1-byte TCP Zero Window Probe (Keep-alive)
        t += 1.0
        pcap.write_packet(t, make_tcp_segment(client_ip, server_ip, c_port, s_port, seq - 1, 501, {"ACK": True}, payload=b"P", ip_id=30))

        # Server responds still win=0 (Zero Window Probe ACK)
        t += 0.005
        pcap.write_packet(t, make_tcp_segment(server_ip, client_ip, s_port, c_port, 501, seq, {"ACK": True}, win=0, ip_id=31))

        # After another 1.5s, server application finally drains buffer and advertises Window Update (win=64000)
        t += 1.5
        pcap.write_packet(t, make_tcp_segment(server_ip, client_ip, s_port, c_port, 501, seq, {"ACK": True}, win=64000, ip_id=40))

        # Client resumes transfer
        for i in range(5):
            t += 0.002
            pcap.write_packet(t, make_tcp_segment(client_ip, server_ip, c_port, s_port, seq, 501, {"ACK": True}, payload=b"RESUMED_DATA" * (mss // 12), ip_id=50 + i))
            seq += mss

        pcap.close()
        return filepath

    @staticmethod
    def generate_multiflow_web(filepath: str) -> str:
        """Generates mixed realistic network session with DNS, HTTP, TLS, ICMP ping."""
        pcap = PcapWriter(filepath)
        t = 1710000500.0
        client_ip = "192.168.1.150"
        dns_server = "1.1.1.1"
        web_server = "142.250.190.46"

        # 1. DNS Query & Response (UDP 53)
        dns_query = b"\x12\x34\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\x07example\x03com\x00\x00\x01\x00\x01"
        dns_resp = b"\x12\x34\x81\x80\x00\x01\x00\x01\x00\x00\x00\x00\x07example\x03com\x00\x00\x01\x00\x01\xc0\x0c\x00\x01\x00\x01\x00\x00\x01\x2c\x00\x04\x8e\xfa\xbe\x2e"
        pcap.write_packet(t, make_udp_packet(client_ip, dns_server, 53210, 53, dns_query, ip_id=1))
        t += 0.012
        pcap.write_packet(t, make_udp_packet(dns_server, client_ip, 53, 53210, dns_resp, ip_id=2))

        # 2. ICMP Ping Request & Reply
        t += 0.005
        pcap.write_packet(t, make_icmp_packet(client_ip, "8.8.8.8", icmp_type=8, seq_num=1, ip_id=3))
        t += 0.018
        pcap.write_packet(t, make_icmp_packet("8.8.8.8", client_ip, icmp_type=0, seq_num=1, ip_id=4))

        # 3. HTTP GET Flow (TCP 80)
        c_port = 49100
        pcap.write_packet(t, make_tcp_segment(client_ip, web_server, c_port, 80, 100, 0, {"SYN": True}, ip_id=10))
        t += 0.014
        pcap.write_packet(t, make_tcp_segment(web_server, client_ip, 80, c_port, 200, 101, {"SYN": True, "ACK": True}, ip_id=11))
        t += 0.014
        pcap.write_packet(t, make_tcp_segment(client_ip, web_server, c_port, 80, 101, 201, {"ACK": True}, ip_id=12))

        http_req = b"GET /index.html HTTP/1.1\r\nHost: example.com\r\nUser-Agent: NetForensics/1.0\r\n\r\n"
        pcap.write_packet(t + 0.001, make_tcp_segment(client_ip, web_server, c_port, 80, 101, 201, {"ACK": True, "PSH": True}, payload=http_req, ip_id=13))

        http_resp = b"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: 1200\r\n\r\n" + (b"<html><body><h1>NetForensics Ready</h1></body></html>" * 24)
        t += 0.020
        pcap.write_packet(t, make_tcp_segment(web_server, client_ip, 80, c_port, 201, 101 + len(http_req), {"ACK": True, "PSH": True}, payload=http_resp, ip_id=14))

        pcap.write_packet(t + 0.005, make_tcp_segment(client_ip, web_server, c_port, 80, 101 + len(http_req), 201 + len(http_resp), {"ACK": True, "FIN": True}, ip_id=15))
        pcap.write_packet(t + 0.019, make_tcp_segment(web_server, client_ip, 80, c_port, 201 + len(http_resp), 102 + len(http_req), {"ACK": True, "FIN": True}, ip_id=16))

        pcap.close()
        return filepath

    @classmethod
    def generate_all_presets(cls, target_dir: str) -> Dict[str, str]:
        """Generates all preset capture files into target directory."""
        os.makedirs(target_dir, exist_ok=True)
        presets = {
            "clean_gigabit": os.path.join(target_dir, "scenario_clean_gigabit.pcap"),
            "packet_loss_drop": os.path.join(target_dir, "scenario_packet_loss_drop.pcap"),
            "high_latency_satellite": os.path.join(target_dir, "scenario_high_latency_satellite.pcap"),
            "bufferbloat_queue": os.path.join(target_dir, "scenario_bufferbloat_queue.pcap"),
            "zero_window_receiver": os.path.join(target_dir, "scenario_zero_window_receiver.pcap"),
            "multiflow_web": os.path.join(target_dir, "scenario_multiflow_web.pcap"),
        }
        cls.generate_clean_gigabit(presets["clean_gigabit"])
        cls.generate_packet_loss_drop(presets["packet_loss_drop"])
        cls.generate_high_latency_satellite(presets["high_latency_satellite"])
        cls.generate_bufferbloat_queue(presets["bufferbloat_queue"])
        cls.generate_zero_window_receiver(presets["zero_window_receiver"])
        cls.generate_multiflow_web(presets["multiflow_web"])
        return presets
