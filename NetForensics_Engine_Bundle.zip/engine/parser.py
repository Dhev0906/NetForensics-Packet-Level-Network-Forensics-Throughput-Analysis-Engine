"""
Packet Parser Module - Decodes raw PCAP/PCAPNG capture files into structured records.
Supports Ethernet, Linux SLL, IPv4, IPv6, ARP, ICMP, TCP (full options), UDP, DNS, TLS/HTTP hints.
"""

import struct
import socket
import os
import time
from typing import List, Dict, Any, Optional, Tuple

try:
    import dpkt
    DPKT_AVAILABLE = True
except ImportError:
    DPKT_AVAILABLE = False


def format_ip(addr_bytes: bytes) -> str:
    """Format raw 4 or 16 bytes IP address to human-readable string."""
    if len(addr_bytes) == 4:
        return socket.inet_ntoa(addr_bytes)
    elif len(addr_bytes) == 16:
        return socket.inet_ntop(socket.AF_INET6, addr_bytes)
    return ""


def format_mac(mac_bytes: bytes) -> str:
    """Format 6 bytes MAC address to XX:XX:XX:XX:XX:XX."""
    if len(mac_bytes) == 6:
        return ":".join(f"{b:02x}" for b in mac_bytes)
    return ""


def hexdump_lines(data: bytes, bytes_per_line: int = 16) -> List[str]:
    """Generate canonical Wireshark-style hex dump lines."""
    lines = []
    for i in range(0, len(data), bytes_per_line):
        chunk = data[i:i + bytes_per_line]
        hex_str = " ".join(f"{b:02x}" for b in chunk)
        if len(chunk) < bytes_per_line:
            hex_str = hex_str.ljust(bytes_per_line * 3 - 1)
        ascii_str = "".join(chr(b) if 32 <= b <= 126 else "." for b in chunk)
        lines.append(f"{i:04x}   {hex_str:<48}   {ascii_str}")
    return lines


class PacketRecord:
    """Represents a single decoded packet with all layer metadata."""

    def __init__(self, index: int, timestamp: float, raw_data: bytes, wire_len: Optional[int] = None):
        self.index: int = index
        self.timestamp: float = timestamp
        self.rel_time: float = 0.0  # Relative time from first packet in capture
        self.wire_len: int = wire_len if wire_len is not None else len(raw_data)
        self.cap_len: int = len(raw_data)
        self.raw_data: bytes = raw_data

        # Layer 2 (Link)
        self.link_type: str = "Ethernet"
        self.src_mac: str = ""
        self.dst_mac: str = ""
        self.vlan_id: Optional[int] = None

        # Layer 3 (Network)
        self.network_proto: str = ""  # "IPv4", "IPv6", "ARP"
        self.src_ip: str = ""
        self.dst_ip: str = ""
        self.ip_ttl: int = 0
        self.ip_tos: int = 0
        self.ip_id: int = 0
        self.ip_df: bool = False
        self.ip_mf: bool = False
        self.ip_frag_offset: int = 0
        self.ip_len: int = 0

        # Layer 4 (Transport)
        self.transport_proto: str = ""  # "TCP", "UDP", "ICMP", "ICMPv6", "OTHER"
        self.src_port: int = 0
        self.dst_port: int = 0

        # TCP Specific
        self.tcp_seq: int = 0
        self.tcp_ack: int = 0
        self.tcp_flags: Dict[str, bool] = {
            "SYN": False, "ACK": False, "FIN": False, "RST": False,
            "PSH": False, "URG": False, "ECE": False, "CWR": False
        }
        self.tcp_raw_flags: int = 0
        self.tcp_win: int = 0
        self.tcp_win_scale: Optional[int] = None
        self.tcp_mss: Optional[int] = None
        self.tcp_sack_perm: bool = False
        self.tcp_sack_blocks: List[Tuple[int, int]] = []
        self.tcp_ts_val: Optional[int] = None
        self.tcp_ts_ecr: Optional[int] = None
        self.tcp_hdr_len: int = 0

        # ICMP Specific
        self.icmp_type: Optional[int] = None
        self.icmp_code: Optional[int] = None

        # Payload
        self.payload: bytes = b""
        self.payload_len: int = 0

        # Higher-layer Application Protocol Hint
        self.app_proto: str = ""
        self.info: str = ""

        # Forensic analysis tags (assigned by Demuxer/Analyzer)
        self.forensic_tags: List[str] = []
        self.rtt_sample: Optional[float] = None
        self.session_id: str = ""
        self.direction: str = ""  # "fwd" or "rev"

    @property
    def flags_summary(self) -> str:
        """Returns compact string representation of TCP flags like [SYN, ACK]."""
        if self.transport_proto != "TCP":
            return ""
        active = [flag for flag, val in self.tcp_flags.items() if val]
        return f"[{', '.join(active)}]" if active else "[]"

    @property
    def conversation_key(self) -> Tuple[str, str, int, int, str]:
        """Normalized bidirectional conversation key."""
        if (self.src_ip, self.src_port) <= (self.dst_ip, self.dst_port):
            return (self.src_ip, self.dst_ip, self.src_port, self.dst_port, self.transport_proto)
        else:
            return (self.dst_ip, self.src_ip, self.dst_port, self.src_port, self.transport_proto)

    @property
    def flow_5tuple(self) -> Tuple[str, int, str, int, str]:
        """Directional 5-tuple (src_ip, src_port, dst_ip, dst_port, proto)."""
        return (self.src_ip, self.src_port, self.dst_ip, self.dst_port, self.transport_proto)

    def to_dict(self, include_hex: bool = False) -> Dict[str, Any]:
        """Convert record to JSON-serializable dictionary."""
        d = {
            "index": self.index,
            "timestamp": self.timestamp,
            "rel_time": round(self.rel_time, 6),
            "wire_len": self.wire_len,
            "cap_len": self.cap_len,
            "src_mac": self.src_mac,
            "dst_mac": self.dst_mac,
            "network_proto": self.network_proto,
            "src_ip": self.src_ip,
            "dst_ip": self.dst_ip,
            "ip_ttl": self.ip_ttl,
            "transport_proto": self.transport_proto,
            "src_port": self.src_port,
            "dst_port": self.dst_port,
            "tcp_seq": self.tcp_seq,
            "tcp_ack": self.tcp_ack,
            "tcp_flags": self.tcp_flags,
            "tcp_flags_str": self.flags_summary,
            "tcp_win": self.tcp_win,
            "tcp_win_scale": self.tcp_win_scale,
            "tcp_mss": self.tcp_mss,
            "tcp_sack_perm": self.tcp_sack_perm,
            "tcp_ts_val": self.tcp_ts_val,
            "tcp_ts_ecr": self.tcp_ts_ecr,
            "icmp_type": self.icmp_type,
            "icmp_code": self.icmp_code,
            "payload_len": self.payload_len,
            "app_proto": self.app_proto,
            "info": self.info,
            "forensic_tags": self.forensic_tags,
            "rtt_sample": round(self.rtt_sample * 1000, 3) if self.rtt_sample is not None else None,
            "session_id": self.session_id,
            "direction": self.direction,
        }
        if include_hex:
            d["hexdump"] = hexdump_lines(self.raw_data)
            d["payload_hex"] = hexdump_lines(self.payload) if self.payload else []
        return d


class PacketParser:
    """High-speed, robust packet parser supporting PCAP and PCAPNG files."""

    def __init__(self):
        pass

    def parse_file(self, file_path: str) -> List[PacketRecord]:
        """Ingests and decodes a .pcap or .pcapng file into PacketRecord list."""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"PCAP file not found: {file_path}")

        records: List[PacketRecord] = []

        # Try dpkt first if available
        if DPKT_AVAILABLE:
            try:
                records = self._parse_with_dpkt(file_path)
                if records:
                    self._normalize_relative_times(records)
                    return records
            except Exception as e:
                # Fallback to native parser
                pass

        records = self._parse_native_pcap(file_path)
        self._normalize_relative_times(records)
        return records

    def _normalize_relative_times(self, records: List[PacketRecord]) -> None:
        if not records:
            return
        t0 = records[0].timestamp
        for rec in records:
            rec.rel_time = max(0.0, rec.timestamp - t0)

    def _parse_with_dpkt(self, file_path: str) -> List[PacketRecord]:
        records: List[PacketRecord] = []
        with open(file_path, "rb") as f:
            magic = f.read(4)
            f.seek(0)

            # Check if PCAP or PCAPNG
            is_pcapng = (magic == b"\x0a\x0d\x0d\x0a")
            if is_pcapng:
                reader = dpkt.pcapng.Reader(f)
            else:
                reader = dpkt.pcap.Reader(f)

            dlt = getattr(reader, "datalink", lambda: 1)()

            idx = 1
            for ts, buf in reader:
                rec = PacketRecord(index=idx, timestamp=float(ts), raw_data=buf, wire_len=len(buf))
                self._decode_layers(rec, buf, dlt)
                records.append(rec)
                idx += 1

        return records

    def _parse_native_pcap(self, file_path: str) -> List[PacketRecord]:
        """Pure-Python native PCAP parser fallback."""
        records: List[PacketRecord] = []
        with open(file_path, "rb") as f:
            hdr = f.read(24)
            if len(hdr) < 24:
                raise ValueError("Corrupt or incomplete PCAP header")

            magic = hdr[:4]
            if magic in (b"\xa1\xb2\xc3\xd4", b"\xa1\xb2\x3c\x4d"):  # Standard microsecond / nanosecond
                endian = ">"
                is_nano = (magic == b"\xa1\xb2\x3c\x4d")
            elif magic in (b"\xd4\xc3\xb2\xa1", b"\x4d\x3c\xb2\xa1"):
                endian = "<"
                is_nano = (magic == b"\x4d\x3c\xb2\xa1")
            else:
                raise ValueError(f"Unsupported PCAP magic header: {magic.hex()}")

            v_maj, v_min, tz, sig, snaplen, dlt = struct.unpack(f"{endian}HHIIII", hdr[4:24])

            idx = 1
            while True:
                pkt_hdr = f.read(16)
                if len(pkt_hdr) < 16:
                    break
                ts_sec, ts_usec, caplen, wirelen = struct.unpack(f"{endian}IIII", pkt_hdr)
                buf = f.read(caplen)
                if len(buf) < caplen:
                    break

                ts = float(ts_sec) + (float(ts_usec) / (1e9 if is_nano else 1e6))
                rec = PacketRecord(index=idx, timestamp=ts, raw_data=buf, wire_len=wirelen)
                self._decode_layers(rec, buf, dlt)
                records.append(rec)
                idx += 1

        return records

    def _decode_layers(self, rec: PacketRecord, buf: bytes, dlt: int) -> None:
        """Demuxes Layer 2 -> Layer 3 -> Layer 4 -> Payload."""
        data = buf
        offset = 0

        # Layer 2: Link Layer
        eth_type = 0
        if dlt == 1 or dlt == 105:  # Ethernet / 802.11
            if len(data) < 14:
                rec.info = "Truncated Ethernet frame"
                return
            rec.dst_mac = format_mac(data[0:6])
            rec.src_mac = format_mac(data[6:12])
            eth_type = struct.unpack("!H", data[12:14])[0]
            offset = 14

            # 802.1Q VLAN Tagging
            if eth_type == 0x8100 and len(data) >= 18:
                tci = struct.unpack("!H", data[14:16])[0]
                rec.vlan_id = tci & 0x0FFF
                eth_type = struct.unpack("!H", data[16:18])[0]
                offset = 18

        elif dlt == 113:  # Linux SLL (Cooked capture)
            if len(data) < 16:
                return
            eth_type = struct.unpack("!H", data[14:16])[0]
            offset = 16
        elif dlt == 127:  # Linux SLL2
            if len(data) < 20:
                return
            eth_type = struct.unpack("!H", data[0:2])[0]
            offset = 20
        elif dlt in (12, 101):  # Raw IP
            if len(data) > 0:
                v = data[0] >> 4
                eth_type = 0x0800 if v == 4 else 0x86DD
            offset = 0
        elif dlt == 0:  # Loopback (Null)
            if len(data) < 4:
                return
            family = struct.unpack("<I", data[:4])[0]
            eth_type = 0x0800 if family in (2, 28) else 0x86DD
            offset = 4
        else:
            rec.network_proto = f"DLT_{dlt}"
            rec.info = f"Unsupported Data Link Type ({dlt})"
            return

        # Layer 3: Network Layer
        if eth_type == 0x0800:  # IPv4
            self._decode_ipv4(rec, data[offset:])
        elif eth_type == 0x86DD:  # IPv6
            self._decode_ipv6(rec, data[offset:])
        elif eth_type == 0x0806:  # ARP
            self._decode_arp(rec, data[offset:])
        else:
            rec.network_proto = f"0x{eth_type:04x}"
            rec.info = f"Unknown EtherType 0x{eth_type:04x}"

    def _decode_ipv4(self, rec: PacketRecord, data: bytes) -> None:
        rec.network_proto = "IPv4"
        if len(data) < 20:
            rec.info = "Truncated IPv4 header"
            return

        ver_ihl = data[0]
        ihl = (ver_ihl & 0x0F) * 4
        if ihl < 20 or len(data) < ihl:
            rec.info = "Malformed IPv4 header length"
            return

        rec.ip_tos = data[1]
        rec.ip_len = struct.unpack("!H", data[2:4])[0]
        rec.ip_id = struct.unpack("!H", data[4:6])[0]
        flags_frag = struct.unpack("!H", data[6:8])[0]
        rec.ip_df = bool(flags_frag & 0x4000)
        rec.ip_mf = bool(flags_frag & 0x2000)
        rec.ip_frag_offset = (flags_frag & 0x1FFF) * 8
        rec.ip_ttl = data[8]
        proto = data[9]
        rec.src_ip = format_ip(data[12:16])
        rec.dst_ip = format_ip(data[16:20])

        payload = data[ihl:]
        self._decode_transport(rec, proto, payload)

    def _decode_ipv6(self, rec: PacketRecord, data: bytes) -> None:
        rec.network_proto = "IPv6"
        if len(data) < 40:
            rec.info = "Truncated IPv6 header"
            return

        plen = struct.unpack("!H", data[4:6])[0]
        next_hdr = data[6]
        rec.ip_ttl = data[7]  # Hop limit
        rec.src_ip = format_ip(data[8:24])
        rec.dst_ip = format_ip(data[24:40])

        payload = data[40:]
        self._decode_transport(rec, next_hdr, payload)

    def _decode_arp(self, rec: PacketRecord, data: bytes) -> None:
        rec.network_proto = "ARP"
        if len(data) < 28:
            rec.info = "Truncated ARP"
            return
        hw_type, proto_type, hw_len, proto_len, opcode = struct.unpack("!HHBBH", data[:8])
        if proto_type == 0x0800 and hw_len == 6 and proto_len == 4:
            src_mac = format_mac(data[8:14])
            src_ip = format_ip(data[14:18])
            dst_mac = format_mac(data[18:24])
            dst_ip = format_ip(data[24:28])
            rec.src_ip = src_ip
            rec.dst_ip = dst_ip
            op_str = "Request" if opcode == 1 else "Reply" if opcode == 2 else f"Opcode {opcode}"
            rec.info = f"ARP {op_str}: Who has {dst_ip}? Tell {src_ip}" if opcode == 1 else f"ARP {op_str}: {src_ip} is at {src_mac}"

    def _decode_transport(self, rec: PacketRecord, proto: int, data: bytes) -> None:
        """Decodes TCP, UDP, ICMP, ICMPv6."""
        if proto == 6:  # TCP
            rec.transport_proto = "TCP"
            self._decode_tcp(rec, data)
        elif proto == 17:  # UDP
            rec.transport_proto = "UDP"
            self._decode_udp(rec, data)
        elif proto == 1:  # ICMP
            rec.transport_proto = "ICMP"
            self._decode_icmp(rec, data)
        elif proto == 58:  # ICMPv6
            rec.transport_proto = "ICMPv6"
            self._decode_icmp(rec, data)
        else:
            rec.transport_proto = f"Proto_{proto}"
            rec.payload = data
            rec.payload_len = len(data)
            rec.info = f"Transport protocol {proto} ({len(data)} bytes)"

    def _decode_tcp(self, rec: PacketRecord, data: bytes) -> None:
        if len(data) < 20:
            rec.info = "Truncated TCP segment"
            return

        rec.src_port, rec.dst_port, rec.tcp_seq, rec.tcp_ack = struct.unpack("!HHII", data[:12])
        data_offset_byte = data[12]
        tcp_hdr_len = ((data_offset_byte >> 4) & 0x0F) * 4
        rec.tcp_hdr_len = tcp_hdr_len

        flags = data[13]
        rec.tcp_raw_flags = flags
        rec.tcp_flags = {
            "FIN": bool(flags & 0x01),
            "SYN": bool(flags & 0x02),
            "RST": bool(flags & 0x04),
            "PSH": bool(flags & 0x08),
            "ACK": bool(flags & 0x10),
            "URG": bool(flags & 0x20),
            "ECE": bool(flags & 0x40),
            "CWR": bool(flags & 0x80),
        }
        rec.tcp_win = struct.unpack("!H", data[14:16])[0]

        # Parse TCP Options if header length > 20
        if tcp_hdr_len > 20 and len(data) >= tcp_hdr_len:
            opt_data = data[20:tcp_hdr_len]
            self._parse_tcp_options(rec, opt_data)

        if len(data) >= tcp_hdr_len:
            rec.payload = data[tcp_hdr_len:]
            rec.payload_len = len(rec.payload)

        # Higher layer protocol hints
        self._infer_app_protocol(rec)

        # Build informative summary line
        flags_active = [k for k, v in rec.tcp_flags.items() if v]
        flag_summary = ",".join(flags_active) if flags_active else "NONE"
        rec.info = f"{rec.src_port} → {rec.dst_port} [{flag_summary}] Seq={rec.tcp_seq} Ack={rec.tcp_ack} Win={rec.tcp_win} Len={rec.payload_len}"

    def _parse_tcp_options(self, rec: PacketRecord, opt_bytes: bytes) -> None:
        """Parses TCP options (MSS, Window Scale, SACK, Timestamps)."""
        i = 0
        n = len(opt_bytes)
        while i < n:
            kind = opt_bytes[i]
            if kind == 0:  # End of Option List
                break
            if kind == 1:  # NOP (No Operation)
                i += 1
                continue

            if i + 1 >= n:
                break
            length = opt_bytes[i + 1]
            if length < 2 or i + length > n:
                break

            val = opt_bytes[i + 2:i + length]
            if kind == 2 and length == 4:  # MSS
                rec.tcp_mss = struct.unpack("!H", val)[0]
            elif kind == 3 and length == 3:  # Window Scale
                rec.tcp_win_scale = val[0]
            elif kind == 4 and length == 2:  # SACK Permitted
                rec.tcp_sack_perm = True
            elif kind == 5:  # SACK Data blocks
                num_blocks = (length - 2) // 8
                rec.tcp_sack_blocks = []
                for b in range(num_blocks):
                    left, right = struct.unpack("!II", val[b * 8:(b + 1) * 8])
                    rec.tcp_sack_blocks.append((left, right))
            elif kind == 8 and length == 10:  # Timestamp
                rec.tcp_ts_val, rec.tcp_ts_ecr = struct.unpack("!II", val)

            i += length

    def _decode_udp(self, rec: PacketRecord, data: bytes) -> None:
        if len(data) < 8:
            rec.info = "Truncated UDP datagram"
            return
        rec.src_port, rec.dst_port, length, checksum = struct.unpack("!HHHH", data[:8])
        rec.payload = data[8:length] if length >= 8 and len(data) >= length else data[8:]
        rec.payload_len = len(rec.payload)

        self._infer_app_protocol(rec)
        rec.info = f"{rec.src_port} → {rec.dst_port} Len={rec.payload_len}"

    def _decode_icmp(self, rec: PacketRecord, data: bytes) -> None:
        if len(data) < 4:
            rec.info = "Truncated ICMP"
            return
        rec.icmp_type = data[0]
        rec.icmp_code = data[1]
        rec.payload = data[4:]
        rec.payload_len = len(rec.payload)

        type_names = {
            0: "Echo (Ping) Reply",
            3: "Destination Unreachable",
            8: "Echo (Ping) Request",
            11: "Time Exceeded (TTL expired)",
        }
        name = type_names.get(rec.icmp_type, f"Type {rec.icmp_type}")
        rec.info = f"ICMP {name} (code={rec.icmp_code})"

    def _infer_app_protocol(self, rec: PacketRecord) -> None:
        """Infers application protocols like DNS, HTTP, TLS, SSH, FTP, NTP, DHCP."""
        ports = {rec.src_port, rec.dst_port}
        if 53 in ports:
            rec.app_proto = "DNS"
        elif 80 in ports or 8080 in ports or 8000 in ports:
            rec.app_proto = "HTTP"
        elif 443 in ports or 8443 in ports:
            rec.app_proto = "TLS/HTTPS"
        elif 22 in ports:
            rec.app_proto = "SSH"
        elif 21 in ports or 20 in ports:
            rec.app_proto = "FTP"
        elif 123 in ports:
            rec.app_proto = "NTP"
        elif 67 in ports or 68 in ports:
            rec.app_proto = "DHCP"
        elif 5353 in ports:
            rec.app_proto = "mDNS"
        elif rec.transport_proto == "TCP":
            rec.app_proto = "TCP"
        elif rec.transport_proto == "UDP":
            rec.app_proto = "UDP"
        else:
            rec.app_proto = rec.transport_proto
