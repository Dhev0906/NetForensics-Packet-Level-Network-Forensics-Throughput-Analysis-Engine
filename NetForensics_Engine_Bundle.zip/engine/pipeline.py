"""
Core Analysis Pipeline - Orchestrates parsing, demuxing, metrics computation,
forensic root-cause diagnosis, and report generation.
"""

import os
from typing import Dict, Any, List, Optional
from .parser import PacketParser, PacketRecord
from .demux import SessionDemuxer, ConversationSession
from .metrics import ForensicMetricsCalculator, SessionMetrics
from .diagnostics import ForensicDiagnosticEngine, DiagnosisReport
from .report_gen import ForensicReportGenerator


class ForensicsPipeline:
    """End-to-end Forensic Ingestion & Analytical Pipeline."""

    def __init__(self):
        self.parser = PacketParser()
        self.demuxer = SessionDemuxer()
        self.calculator = ForensicMetricsCalculator()
        self.diagnostician = ForensicDiagnosticEngine()

    def process_pcap(self, pcap_path: str, max_packets: Optional[int] = None) -> Dict[str, Any]:
        """Runs full forensic pipeline on target PCAP file."""
        if not os.path.exists(pcap_path):
            raise FileNotFoundError(f"PCAP file not found: {pcap_path}")

        # 1. Ingestion & Decoding
        packets: List[PacketRecord] = self.parser.parse_file(pcap_path)
        if max_packets and len(packets) > max_packets:
            packets = packets[:max_packets]

        if not packets:
            return {
                "filename": os.path.basename(pcap_path),
                "summary": {"total_packets": 0, "total_wire_bytes": 0, "duration_sec": 0.0},
                "sessions": [],
                "primary_diagnosis": {"verdict": "EMPTY_CAPTURE", "headline": "No packets found"},
                "packets_sample": []
            }

        # 2. Demultiplexing 5-Tuple Conversations
        sessions_map: Dict[str, ConversationSession] = self.demuxer.demux(packets)

        # 3. Mathematical Computation per Session
        session_summaries = []
        detailed_sessions: Dict[str, Dict[str, Any]] = {}
        all_metrics: List[SessionMetrics] = []

        # Find primary dominant session (by wire bytes)
        dominant_session_id = None
        max_bytes = -1

        for sess_id, session in sessions_map.items():
            metrics = self.calculator.analyze_session(session)
            all_metrics.append(metrics)
            diag_report = self.diagnostician.diagnose(session, metrics)

            summary_dict = session.to_summary_dict()
            summary_dict["loss_rate_pct"] = metrics.packet_loss_rate_pct
            summary_dict["retrans_rate_pct"] = metrics.retransmission_rate_pct
            summary_dict["retrans_count"] = metrics.retransmission_count
            summary_dict["dup_ack_count"] = metrics.duplicate_ack_count
            summary_dict["avg_rtt_ms"] = metrics.avg_rtt_ms
            summary_dict["srtt_ms"] = metrics.srtt_ms
            summary_dict["bufferbloat_index_pct"] = metrics.bufferbloat_index_pct
            summary_dict["diagnosis_verdict"] = diag_report.primary_verdict.value
            summary_dict["diagnosis_severity"] = diag_report.severity.value
            summary_dict["diagnosis_headline"] = diag_report.headline

            session_summaries.append(summary_dict)

            detailed_sessions[sess_id] = {
                "session": summary_dict,
                "metrics": metrics.to_dict(),
                "diagnosis": diag_report.to_dict(),
                "timeseries_throughput": metrics.timeseries_throughput,
                "timeseries_rtt": metrics.timeseries_rtt,
                "timeseries_tcptrace": metrics.timeseries_tcptrace,
            }

            if session.total_wire_bytes > max_bytes:
                max_bytes = session.total_wire_bytes
                dominant_session_id = sess_id

        # Aggregate Global Capture Summary
        total_packets = len(packets)
        total_wire_bytes = sum(p.wire_len for p in packets)
        total_payload_bytes = sum(p.payload_len for p in packets)
        duration_sec = max(0.0001, packets[-1].timestamp - packets[0].timestamp)
        avg_wire_mbps = (total_wire_bytes * 8) / (duration_sec * 1e6)
        avg_goodput_mbps = (total_payload_bytes * 8) / (duration_sec * 1e6)
        total_retrans = sum(m.retransmission_count for m in all_metrics)
        total_dup_acks = sum(m.duplicate_ack_count for m in all_metrics)
        total_zero_wins = sum(m.zero_window_count for m in all_metrics)

        all_rtts = [m.avg_rtt_ms for m in all_metrics if m.avg_rtt_ms > 0]
        global_avg_rtt = (sum(all_rtts) / len(all_rtts)) if all_rtts else 0.0

        all_loss = [m.packet_loss_rate_pct for m in all_metrics]
        global_loss_pct = max(all_loss) if all_loss else 0.0

        # Primary diagnosis is from dominant session or worst-severity session
        primary_diag = None
        if dominant_session_id and dominant_session_id in detailed_sessions:
            # Check if another session has CRITICAL severity
            crit_sessions = [s for s in session_summaries if s.get("diagnosis_severity") == "CRITICAL"]
            target_id = crit_sessions[0]["session_id"] if crit_sessions else dominant_session_id
            primary_diag = detailed_sessions[target_id]["diagnosis"]
        else:
            primary_diag = {
                "verdict": "NO_TCP_FLOW",
                "severity": "INFO",
                "confidence_score": 1.0,
                "headline": "Non-TCP / Light Capture Analyzed",
                "summary": "No dominant TCP flows were detected.",
                "evidence_chain": [],
                "remediation_steps": []
            }

        # Protocol Breakdown Stats
        proto_counts: Dict[str, int] = {}
        proto_bytes: Dict[str, int] = {}
        for p in packets:
            proto = p.app_proto or p.transport_proto or p.network_proto or "OTHER"
            proto_counts[proto] = proto_counts.get(proto, 0) + 1
            proto_bytes[proto] = proto_bytes.get(proto, 0) + p.wire_len

        # Packet list sample for deep inspection table
        packet_list_json = [p.to_dict(include_hex=True) for p in packets]

        result = {
            "filename": os.path.basename(pcap_path),
            "filepath": pcap_path,
            "summary": {
                "total_packets": total_packets,
                "total_wire_bytes": total_wire_bytes,
                "total_payload_bytes": total_payload_bytes,
                "duration_sec": round(duration_sec, 4),
                "avg_wire_mbps": round(avg_wire_mbps, 3),
                "avg_goodput_mbps": round(avg_goodput_mbps, 3),
                "goodput_efficiency_pct": round((total_payload_bytes / total_wire_bytes * 100.0), 2) if total_wire_bytes > 0 else 0.0,
                "protocol_overhead_pct": round(((total_wire_bytes - total_payload_bytes) / total_wire_bytes * 100.0), 2) if total_wire_bytes > 0 else 0.0,
                "packet_loss_rate_pct": round(global_loss_pct, 2),
                "total_retransmissions": total_retrans,
                "total_duplicate_acks": total_dup_acks,
                "total_zero_windows": total_zero_wins,
                "avg_rtt_ms": round(global_avg_rtt, 3),
                "total_sessions": len(sessions_map),
                "dominant_session_id": dominant_session_id,
            },
            "protocol_breakdown": {
                "counts": proto_counts,
                "bytes": proto_bytes,
            },
            "primary_diagnosis": primary_diag,
            "sessions": session_summaries,
            "detailed_sessions": detailed_sessions,
            "packets": packet_list_json,
        }

        return result
