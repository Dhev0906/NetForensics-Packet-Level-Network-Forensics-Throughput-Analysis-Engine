"""
Packet-Level Forensics and Throughput Analysis Engine (NetForensics)
Advanced packet-level network diagnostics, session demultiplexing,
throughput/delay/loss mathematical modeling, and automated forensic root-cause analysis.
"""

from .parser import PacketParser, PacketRecord
from .demux import SessionDemuxer, ConversationSession, FlowDirection
from .metrics import ForensicMetricsCalculator, SessionMetrics
from .diagnostics import ForensicDiagnosticEngine, DiagnosisReport, BottleneckVerdict
from .generator import ScenarioGenerator

__version__ = "1.0.0"
__all__ = [
    "PacketParser",
    "PacketRecord",
    "SessionDemuxer",
    "ConversationSession",
    "FlowDirection",
    "ForensicMetricsCalculator",
    "SessionMetrics",
    "ForensicDiagnosticEngine",
    "DiagnosisReport",
    "BottleneckVerdict",
    "ScenarioGenerator",
]
