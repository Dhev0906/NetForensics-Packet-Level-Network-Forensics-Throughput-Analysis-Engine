"""
Forensic Report Generator - Generates Markdown, JSON, and PDF Forensic Analysis Reports.
"""

import os
import json
from datetime import datetime
from typing import Dict, Any, List, Optional

try:
    from reportlab.lib.pagesizes import letter
    from reportlab.lib import colors
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
    REPORTLAB_AVAILABLE = True
except ImportError:
    REPORTLAB_AVAILABLE = False


class ForensicReportGenerator:
    """Produces structured academic and enterprise forensic investigation reports."""

    def __init__(self, capture_file: str, analysis_result: Dict[str, Any]):
        self.capture_file = capture_file
        self.filename = os.path.basename(capture_file)
        self.data = analysis_result

    def generate_markdown(self) -> str:
        """Generates comprehensive GitHub-flavored Markdown forensic report."""
        summary = self.data.get("summary", {})
        sessions = self.data.get("sessions", [])
        primary_diag = self.data.get("primary_diagnosis", {})

        md = []
        md.append(f"# 🔬 Packet-Level Forensics & Throughput Analysis Report")
        md.append(f"**Target Capture File:** `{self.filename}`  ")
        md.append(f"**Report Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  ")
        md.append(f"**Forensic Engine Version:** `v1.0.0`\n")
        md.append("---\n")

        # 1. Executive Summary & Diagnostic Verdict
        verdict = primary_diag.get("verdict", "N/A")
        severity = primary_diag.get("severity", "N/A")
        confidence = primary_diag.get("confidence_score", 0.0) * 100
        headline = primary_diag.get("headline", "Investigation Complete")

        md.append("## 🚨 Executive Forensic Verdict")
        md.append(f"> **Verdict:** `{verdict}` | **Severity:** `{severity}` | **Confidence:** `{confidence:.0f}%`\n")
        md.append(f"### {headline}\n")
        md.append(f"{primary_diag.get('summary', 'No summary available.')}\n")

        if primary_diag.get("mathematical_proof"):
            md.append("### 📐 Mathematical Derivation & Proof")
            md.append(f"```text\n{primary_diag.get('mathematical_proof')}\n```\n")

        # 2. Key Telemetry Metrics Table
        md.append("## 📊 Capture Telemetry & Flow Statistics")
        md.append("| Metric | Measured Value | Description |")
        md.append("| :--- | :--- | :--- |")
        md.append(f"| **Total Captured Packets** | `{summary.get('total_packets', 0):,}` | Raw frame count decoded |")
        md.append(f"| **Total Wire Volume** | `{summary.get('total_wire_bytes', 0):,} bytes` | L2/L3/L4 headers + payload |")
        md.append(f"| **Total Application Goodput** | `{summary.get('total_payload_bytes', 0):,} bytes` | Pure application data payload |")
        md.append(f"| **Capture Time Span** | `{summary.get('duration_sec', 0.0):.3f} seconds` | First packet to last packet delta |")
        md.append(f"| **Avg Wire Bandwidth** | `{summary.get('avg_wire_mbps', 0.0):.2f} Mbps` | Total wire bits / duration |")
        md.append(f"| **Avg Goodput Rate** | `{summary.get('avg_goodput_mbps', 0.0):.2f} Mbps` | Application bits / duration |")
        md.append(f"| **Packet Loss Rate** | `{summary.get('packet_loss_rate_pct', 0.0):.2f}%` | Retransmission / sequence gaps |")
        md.append(f"| **Smoothed RTT (SRTT)** | `{summary.get('avg_rtt_ms', 0.0):.2f} ms` | RFC 6298 moving average latency |")
        md.append(f"| **Demultiplexed Conversations** | `{len(sessions)} sessions` | Unique 5-tuple bidirectional flows |\n")

        # 3. Demultiplexed Sessions Breakdown
        md.append("## 🔀 Demultiplexed Conversation Sessions")
        md.append("| Session ID | Protocol | Client Endpoint | Server Endpoint | Packets | Wire MB | Wire Mbps | Loss % |")
        md.append("| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |")
        for s in sessions:
            wire_mb = s.get("total_wire_bytes", 0) / (1024 * 1024)
            md.append(f"| `{s.get('session_id')}` | **{s.get('proto')}** | `{s.get('client_ip')}:{s.get('client_port')}` | `{s.get('server_ip')}:{s.get('server_port')}` | {s.get('packet_count')} | {wire_mb:.3f} MB | {s.get('wire_mbps', 0.0):.2f} | {s.get('loss_rate_pct', 0.0):.1f}% |")
        md.append("")

        # 4. Forensic Evidence Chain
        chain = primary_diag.get("evidence_chain", [])
        if chain:
            md.append("## 🔍 Chronological Forensic Evidence Audit Chain")
            md.append("| Step | Frame # | Rel Time (s) | Forensic Event | Technical Observations |")
            md.append("| :--- | :--- | :--- | :--- | :--- |")
            for item in chain:
                md.append(f"| {item.get('step')} | `#{item.get('packet_index')}` | `+{item.get('rel_time'):.4f}s` | **{item.get('event')}** | {item.get('details')} |")
            md.append("")

        # 5. Remediation Steps
        remediation = primary_diag.get("remediation_steps", [])
        if remediation:
            md.append("## 🛠️ Actionable Engineering Remediation")
            for idx, step in enumerate(remediation, 1):
                md.append(f"{idx}. {step}")
            md.append("")

        return "\n".join(md)

    def generate_pdf(self, output_pdf_path: str) -> Optional[str]:
        """Generates a professional PDF forensic summary report."""
        if not REPORTLAB_AVAILABLE:
            return None

        doc = SimpleDocTemplate(output_pdf_path, pagesize=letter, rightMargin=36, leftMargin=36, topMargin=36, bottomMargin=36)
        styles = getSampleStyleSheet()

        title_style = ParagraphStyle(
            'DocTitle',
            parent=styles['Heading1'],
            fontSize=18,
            textColor=colors.HexColor("#0f172a"),
            spaceAfter=6,
        )
        sub_style = ParagraphStyle(
            'SubTitle',
            parent=styles['Normal'],
            fontSize=10,
            textColor=colors.HexColor("#475569"),
            spaceAfter=14,
        )
        h2_style = ParagraphStyle(
            'Heading2Custom',
            parent=styles['Heading2'],
            fontSize=13,
            textColor=colors.HexColor("#1e293b"),
            spaceBefore=12,
            spaceAfter=6,
        )
        body_style = ParagraphStyle(
            'BodyCustom',
            parent=styles['Normal'],
            fontSize=9,
            leading=12,
            textColor=colors.HexColor("#334155"),
        )
        verdict_box_style = ParagraphStyle(
            'VerdictBox',
            parent=styles['Normal'],
            fontSize=11,
            leading=14,
            textColor=colors.HexColor("#0f172a"),
            backColor=colors.HexColor("#f1f5f9"),
            borderPadding=8,
            spaceAfter=10,
        )

        elements = []

        # Title
        elements.append(Paragraph("<b>Packet-Level Forensics & Throughput Analysis Report</b>", title_style))
        elements.append(Paragraph(f"Capture Target: <b>{self.filename}</b> | Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", sub_style))
        elements.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#cbd5e1"), spaceAfter=10))

        # Executive Verdict Box
        primary_diag = self.data.get("primary_diagnosis", {})
        verdict = primary_diag.get("verdict", "OPTIMAL")
        severity = primary_diag.get("severity", "HEALTHY")
        confidence = primary_diag.get("confidence_score", 0.95) * 100
        headline = primary_diag.get("headline", "Investigation Summary")
        summary_txt = primary_diag.get("summary", "")

        box_html = f"<b>FORENSIC VERDICT:</b> {verdict} &nbsp;&nbsp;|&nbsp;&nbsp; <b>SEVERITY:</b> {severity} &nbsp;&nbsp;|&nbsp;&nbsp; <b>CONFIDENCE:</b> {confidence:.0f}%<br/><b>{headline}</b><br/>{summary_txt}"
        elements.append(Paragraph(box_html, verdict_box_style))

        # Telemetry Summary Table
        elements.append(Paragraph("<b>1. Telemetry & Capture Summary</b>", h2_style))
        summary = self.data.get("summary", {})
        table_data = [
            ["Metric", "Value", "Metric", "Value"],
            ["Total Packets", f"{summary.get('total_packets', 0):,}", "Duration", f"{summary.get('duration_sec', 0.0):.3f} s"],
            ["Total Wire Data", f"{summary.get('total_wire_bytes', 0):,} B", "Goodput Data", f"{summary.get('total_payload_bytes', 0):,} B"],
            ["Avg Bandwidth", f"{summary.get('avg_wire_mbps', 0.0):.2f} Mbps", "Avg Goodput", f"{summary.get('avg_goodput_mbps', 0.0):.2f} Mbps"],
            ["Packet Loss Rate", f"{summary.get('packet_loss_rate_pct', 0.0):.2f}%", "Smoothed RTT", f"{summary.get('avg_rtt_ms', 0.0):.2f} ms"],
        ]
        t = Table(table_data, colWidths=[120, 140, 120, 140])
        t.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#1e293b")),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#e2e8f0")),
            ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor("#f8fafc")),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.HexColor("#ffffff"), colors.HexColor("#f8fafc")]),
        ]))
        elements.append(t)
        elements.append(Spacer(1, 10))

        # Mathematical Proof
        if primary_diag.get("mathematical_proof"):
            elements.append(Paragraph("<b>2. Mathematical Proof & Derivations</b>", h2_style))
            elements.append(Paragraph(f"<i>{primary_diag.get('mathematical_proof')}</i>", body_style))
            elements.append(Spacer(1, 8))

        # Evidence Chain Table
        chain = primary_diag.get("evidence_chain", [])
        if chain:
            elements.append(Paragraph("<b>3. Forensic Evidence Audit Chain</b>", h2_style))
            chain_rows = [["Step", "Frame", "Time", "Event", "Forensic Detail"]]
            for item in chain[:8]:  # Limit top entries for page fit
                chain_rows.append([
                    str(item.get("step")),
                    f"#{item.get('packet_index')}",
                    f"+{item.get('rel_time'):.3f}s",
                    item.get("event")[:28],
                    item.get("details")[:55] + ("..." if len(item.get("details", "")) > 55 else "")
                ])
            t_chain = Table(chain_rows, colWidths=[30, 45, 55, 150, 240])
            t_chain.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#334155")),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 7.5),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5e1")),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.HexColor("#ffffff"), colors.HexColor("#f1f5f9")]),
            ]))
            elements.append(t_chain)
            elements.append(Spacer(1, 10))

        # Remediation
        remediation = primary_diag.get("remediation_steps", [])
        if remediation:
            elements.append(Paragraph("<b>4. Engineering Remediation Steps</b>", h2_style))
            rem_html = "<br/>".join([f"• <b>{r}</b>" for r in remediation])
            elements.append(Paragraph(rem_html, body_style))

        doc.build(elements)
        return output_pdf_path
