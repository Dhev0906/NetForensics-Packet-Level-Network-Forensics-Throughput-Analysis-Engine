"""
Forensic Metrics & Mathematical Computation Engine
Calculates throughput, goodput, RTT, RFC 6298 SRTT, jitter, packet loss rate,
retransmission classifications, time-sequence ladder data, and bufferbloat metrics.
"""

import math
from typing import List, Dict, Tuple, Optional, Any
from .parser import PacketRecord
from .demux import ConversationSession


class SessionMetrics:
    """Encapsulates all computed mathematical metrics for a conversation session."""

    def __init__(self, session_id: str):
        self.session_id: str = session_id

        # Throughput & Bandwidth
        self.duration_sec: float = 0.0
        self.total_wire_bytes: int = 0
        self.total_payload_bytes: int = 0
        self.avg_wire_throughput_mbps: float = 0.0
        self.avg_goodput_mbps: float = 0.0
        self.peak_wire_throughput_mbps: float = 0.0
        self.peak_goodput_mbps: float = 0.0
        self.burstiness_factor: float = 1.0
        self.protocol_overhead_pct: float = 0.0
        self.goodput_efficiency_pct: float = 0.0

        # Delay & Latency
        self.handshake_rtt_ms: Optional[float] = None
        self.min_rtt_ms: float = 0.0
        self.max_rtt_ms: float = 0.0
        self.avg_rtt_ms: float = 0.0
        self.median_rtt_ms: float = 0.0
        self.p95_rtt_ms: float = 0.0
        self.srtt_ms: float = 0.0  # RFC 6298 Smoothed RTT
        self.rttvar_ms: float = 0.0  # RFC 6298 RTT Variance
        self.rto_ms: float = 0.0  # Retransmission Timeout
        self.avg_jitter_ms: float = 0.0
        self.max_jitter_ms: float = 0.0
        self.bufferbloat_index_pct: float = 0.0  # (Max - Min) / Min * 100

        # Loss & Retransmission
        self.total_packets: int = 0
        self.retransmission_count: int = 0
        self.fast_retransmission_count: int = 0
        self.timeout_retransmission_count: int = 0
        self.duplicate_ack_count: int = 0
        self.out_of_order_count: int = 0
        self.packet_loss_rate_pct: float = 0.0
        self.retransmission_rate_pct: float = 0.0

        # TCP Window Dynamics
        self.max_advertised_win_bytes: int = 0
        self.min_advertised_win_bytes: int = 0
        self.avg_advertised_win_bytes: float = 0.0
        self.zero_window_count: int = 0
        self.window_full_count: int = 0
        self.bdp_bytes: float = 0.0  # Bandwidth-Delay Product

        # Timeseries data for rich visual charting
        self.timeseries_throughput: List[Dict[str, Any]] = []  # [{time, wire_mbps, goodput_mbps, pps}]
        self.timeseries_rtt: List[Dict[str, Any]] = []  # [{time, rtt_ms, srtt_ms, rttvar_ms}]
        self.timeseries_tcptrace: List[Dict[str, Any]] = []  # [{time, seq, ack, win, len, type}]
        self.timeseries_window: List[Dict[str, Any]] = []  # [{time, win_bytes, in_flight}]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "session_id": self.session_id,
            "duration_sec": round(self.duration_sec, 4),
            "total_wire_bytes": self.total_wire_bytes,
            "total_payload_bytes": self.total_payload_bytes,
            "avg_wire_throughput_mbps": round(self.avg_wire_throughput_mbps, 3),
            "avg_goodput_mbps": round(self.avg_goodput_mbps, 3),
            "peak_wire_throughput_mbps": round(self.peak_wire_throughput_mbps, 3),
            "peak_goodput_mbps": round(self.peak_goodput_mbps, 3),
            "burstiness_factor": round(self.burstiness_factor, 2),
            "protocol_overhead_pct": round(self.protocol_overhead_pct, 2),
            "goodput_efficiency_pct": round(self.goodput_efficiency_pct, 2),
            "handshake_rtt_ms": round(self.handshake_rtt_ms, 3) if self.handshake_rtt_ms is not None else None,
            "min_rtt_ms": round(self.min_rtt_ms, 3),
            "max_rtt_ms": round(self.max_rtt_ms, 3),
            "avg_rtt_ms": round(self.avg_rtt_ms, 3),
            "median_rtt_ms": round(self.median_rtt_ms, 3),
            "p95_rtt_ms": round(self.p95_rtt_ms, 3),
            "srtt_ms": round(self.srtt_ms, 3),
            "rttvar_ms": round(self.rttvar_ms, 3),
            "rto_ms": round(self.rto_ms, 3),
            "avg_jitter_ms": round(self.avg_jitter_ms, 3),
            "max_jitter_ms": round(self.max_jitter_ms, 3),
            "bufferbloat_index_pct": round(self.bufferbloat_index_pct, 1),
            "total_packets": self.total_packets,
            "retransmission_count": self.retransmission_count,
            "fast_retransmission_count": self.fast_retransmission_count,
            "timeout_retransmission_count": self.timeout_retransmission_count,
            "duplicate_ack_count": self.duplicate_ack_count,
            "out_of_order_count": self.out_of_order_count,
            "packet_loss_rate_pct": round(self.packet_loss_rate_pct, 3),
            "retransmission_rate_pct": round(self.retransmission_rate_pct, 3),
            "max_advertised_win_bytes": self.max_advertised_win_bytes,
            "min_advertised_win_bytes": self.min_advertised_win_bytes,
            "avg_advertised_win_bytes": round(self.avg_advertised_win_bytes, 1),
            "zero_window_count": self.zero_window_count,
            "window_full_count": self.window_full_count,
            "bdp_bytes": round(self.bdp_bytes, 1),
        }


class ForensicMetricsCalculator:
    """Performs deep mathematical analysis on packet captures and sessions."""

    def __init__(self, bin_interval_sec: Optional[float] = None):
        self.default_bin_interval: Optional[float] = bin_interval_sec

    def analyze_session(self, session: ConversationSession) -> SessionMetrics:
        """Computes all forensic metrics, RTT models, and timeseries for a session."""
        m = SessionMetrics(session.session_id)
        m.duration_sec = session.duration
        m.total_wire_bytes = session.total_wire_bytes
        m.total_payload_bytes = session.total_payload_bytes
        m.total_packets = session.packet_count

        if session.duration > 0:
            m.avg_wire_throughput_mbps = (session.total_wire_bytes * 8) / (session.duration * 1e6)
            m.avg_goodput_mbps = (session.total_payload_bytes * 8) / (session.duration * 1e6)

        if session.total_wire_bytes > 0:
            m.goodput_efficiency_pct = (session.total_payload_bytes / session.total_wire_bytes) * 100.0
            m.protocol_overhead_pct = 100.0 - m.goodput_efficiency_pct

        if session.handshake_rtt is not None:
            m.handshake_rtt_ms = session.handshake_rtt * 1000.0

        # Perform deep TCP tracking if protocol is TCP
        if session.proto == "TCP":
            self._analyze_tcp_dynamics(session, m)
        else:
            self._analyze_generic_dynamics(session, m)

        # Generate rolling throughput timeseries
        self._generate_throughput_timeseries(session, m)

        # Calculate Bandwidth-Delay Product (BDP)
        base_rtt_sec = (m.min_rtt_ms / 1000.0) if m.min_rtt_ms > 0 else (m.handshake_rtt_ms / 1000.0 if m.handshake_rtt_ms else 0.02)
        m.bdp_bytes = (m.avg_wire_throughput_mbps * 1e6 / 8.0) * base_rtt_sec

        return m

    def _analyze_tcp_dynamics(self, session: ConversationSession, m: SessionMetrics) -> None:
        """Deep TCP sequence number, RTT, loss, and window dynamics tracking."""
        packets = session.packets
        if not packets:
            return

        # Directional sequence tracking
        # For forward (client->server):
        #   fwd sends data (seq, seq+len) -> rev acknowledges with ack
        # For reverse (server->client):
        #   rev sends data (seq, seq+len) -> fwd acknowledges with ack

        fwd_seq_history: Dict[int, List[Tuple[float, int, PacketRecord]]] = {}  # seq -> [(time, len, pkt)]
        rev_seq_history: Dict[int, List[Tuple[float, int, PacketRecord]]] = {}

        last_fwd_ack: Optional[int] = None
        fwd_dup_ack_streak: int = 0
        last_rev_ack: Optional[int] = None
        rev_dup_ack_streak: int = 0

        rtt_samples: List[Tuple[float, float]] = []  # [(time, rtt_sec)]
        jitter_samples: List[float] = []
        win_sizes: List[int] = []

        srtt: Optional[float] = None
        rttvar: Optional[float] = None
        alpha = 0.125
        beta = 0.25

        prev_transit_delta: Optional[float] = None
        current_jitter: float = 0.0

        retrans_count = 0
        fast_retrans_count = 0
        timeout_retrans_count = 0
        dup_ack_count = 0
        out_of_order_count = 0
        zero_win_count = 0
        win_full_count = 0

        fwd_scale = 1 << session.client_win_scale if session.client_win_scale else 1
        rev_scale = 1 << session.server_win_scale if session.server_win_scale else 1

        fwd_max_seq_sent = 0
        rev_max_seq_sent = 0

        for pkt in packets:
            is_fwd = (pkt.src_ip == session.client_ip and pkt.src_port == session.client_port)
            flags = pkt.tcp_flags
            seq = pkt.tcp_seq
            ack = pkt.tcp_ack
            plen = pkt.payload_len
            scale = fwd_scale if is_fwd else rev_scale
            calc_win = pkt.tcp_win * scale
            win_sizes.append(calc_win)

            if pkt.tcp_win == 0 and not flags.get("RST") and not flags.get("SYN"):
                zero_win_count += 1
                pkt.forensic_tags.append("TCP Zero Window")

            # Tcptrace record
            m.timeseries_tcptrace.append({
                "time": round(pkt.rel_time, 5),
                "dir": "fwd" if is_fwd else "rev",
                "seq": seq,
                "ack": ack if flags.get("ACK") else None,
                "len": plen,
                "win": calc_win,
                "flags": pkt.flags_summary,
                "is_retrans": False,
                "is_dup_ack": False,
            })

            # 1. Sequence & Retransmission Tracking
            if is_fwd:
                if plen > 0:
                    if seq in fwd_seq_history:
                        # Retransmission detected!
                        retrans_count += 1
                        pkt.forensic_tags.append("TCP Retransmission")
                        m.timeseries_tcptrace[-1]["is_retrans"] = True
                        if rev_dup_ack_streak >= 3:
                            fast_retrans_count += 1
                            pkt.forensic_tags.append("Fast Retransmission")
                        else:
                            timeout_retrans_count += 1
                            pkt.forensic_tags.append("Timeout Retransmission (RTO)")
                    else:
                        if fwd_max_seq_sent > 0 and seq < fwd_max_seq_sent:
                            out_of_order_count += 1
                            pkt.forensic_tags.append("TCP Out-of-Order")
                        fwd_max_seq_sent = max(fwd_max_seq_sent, seq + plen)

                    if seq not in fwd_seq_history:
                        fwd_seq_history[seq] = []
                    fwd_seq_history[seq].append((pkt.timestamp, plen, pkt))

                # Handle incoming ACKs acknowledging reverse data
                if flags.get("ACK"):
                    if last_fwd_ack is not None and ack == last_fwd_ack and plen == 0:
                        fwd_dup_ack_streak += 1
                        dup_ack_count += 1
                        pkt.forensic_tags.append(f"TCP Dup ACK #{fwd_dup_ack_streak}")
                        m.timeseries_tcptrace[-1]["is_dup_ack"] = True
                    else:
                        fwd_dup_ack_streak = 0
                        last_fwd_ack = ack

                    # Calculate RTT against reverse sent segments
                    # An ACK acknowledging seq in rev_seq_history
                    matched_time = None
                    for sent_seq, entries in list(rev_seq_history.items()):
                        # If ack acknowledges this sent segment
                        for sent_time, sent_len, sent_pkt in entries:
                            if sent_seq + sent_len == ack and len(entries) == 1:
                                # Karn's Algorithm: Only measure RTT on non-retransmitted segments
                                matched_time = sent_time
                                break
                    if matched_time is not None:
                        rtt = max(0.00001, pkt.timestamp - matched_time)
                        pkt.rtt_sample = rtt
                        rtt_samples.append((pkt.rel_time, rtt))

            else:  # Reverse direction (Server -> Client)
                if plen > 0:
                    if seq in rev_seq_history:
                        retrans_count += 1
                        pkt.forensic_tags.append("TCP Retransmission")
                        m.timeseries_tcptrace[-1]["is_retrans"] = True
                        if fwd_dup_ack_streak >= 3:
                            fast_retrans_count += 1
                            pkt.forensic_tags.append("Fast Retransmission")
                        else:
                            timeout_retrans_count += 1
                            pkt.forensic_tags.append("Timeout Retransmission (RTO)")
                    else:
                        if rev_max_seq_sent > 0 and seq < rev_max_seq_sent:
                            out_of_order_count += 1
                            pkt.forensic_tags.append("TCP Out-of-Order")
                        rev_max_seq_sent = max(rev_max_seq_sent, seq + plen)

                    if seq not in rev_seq_history:
                        rev_seq_history[seq] = []
                    rev_seq_history[seq].append((pkt.timestamp, plen, pkt))

                # Handle incoming ACKs acknowledging forward data
                if flags.get("ACK"):
                    if last_rev_ack is not None and ack == last_rev_ack and plen == 0:
                        rev_dup_ack_streak += 1
                        dup_ack_count += 1
                        pkt.forensic_tags.append(f"TCP Dup ACK #{rev_dup_ack_streak}")
                        m.timeseries_tcptrace[-1]["is_dup_ack"] = True
                    else:
                        rev_dup_ack_streak = 0
                        last_rev_ack = ack

                    # Calculate RTT against forward sent segments
                    matched_time = None
                    for sent_seq, entries in list(fwd_seq_history.items()):
                        for sent_time, sent_len, sent_pkt in entries:
                            if sent_seq + sent_len == ack and len(entries) == 1:
                                matched_time = sent_time
                                break
                    if matched_time is not None:
                        rtt = max(0.00001, pkt.timestamp - matched_time)
                        pkt.rtt_sample = rtt
                        rtt_samples.append((pkt.rel_time, rtt))

        # 2. Process RTT & RFC 6298 Smoothed RTT (SRTT)
        if rtt_samples:
            rtt_vals_ms = [r[1] * 1000.0 for r in rtt_samples]
            m.min_rtt_ms = min(rtt_vals_ms)
            m.max_rtt_ms = max(rtt_vals_ms)
            m.avg_rtt_ms = sum(rtt_vals_ms) / len(rtt_vals_ms)
            sorted_rtt = sorted(rtt_vals_ms)
            m.median_rtt_ms = sorted_rtt[len(sorted_rtt) // 2]
            p95_idx = min(len(sorted_rtt) - 1, int(len(sorted_rtt) * 0.95))
            m.p95_rtt_ms = sorted_rtt[p95_idx]

            # RFC 6298 Iterative SRTT / RTTVAR
            for t_rel, rtt_sec in rtt_samples:
                rtt_m = rtt_sec * 1000.0
                if srtt is None:
                    srtt = rtt_m
                    rttvar = rtt_m / 2.0
                else:
                    rttvar = (1 - beta) * rttvar + beta * abs(srtt - rtt_m)
                    srtt = (1 - alpha) * srtt + alpha * rtt_m
                rto = srtt + max(10.0, 4.0 * rttvar)

                m.timeseries_rtt.append({
                    "time": round(t_rel, 5),
                    "rtt_ms": round(rtt_m, 3),
                    "srtt_ms": round(srtt, 3),
                    "rttvar_ms": round(rttvar, 3),
                    "rto_ms": round(rto, 3),
                })

            m.srtt_ms = srtt or m.avg_rtt_ms
            m.rttvar_ms = rttvar or 0.0
            m.rto_ms = m.srtt_ms + max(10.0, 4.0 * m.rttvar_ms)

            # Jitter calculation (RFC 3550)
            for i in range(1, len(rtt_samples)):
                d = abs((rtt_samples[i][1] - rtt_samples[i - 1][1]) * 1000.0)
                current_jitter = current_jitter + (d - current_jitter) / 16.0
                jitter_samples.append(current_jitter)

            if jitter_samples:
                m.avg_jitter_ms = sum(jitter_samples) / len(jitter_samples)
                m.max_jitter_ms = max(jitter_samples)

            if m.min_rtt_ms > 0:
                m.bufferbloat_index_pct = max(0.0, ((m.max_rtt_ms - m.min_rtt_ms) / m.min_rtt_ms) * 100.0)

        elif session.handshake_rtt is not None:
            m.min_rtt_ms = session.handshake_rtt * 1000.0
            m.max_rtt_ms = session.handshake_rtt * 1000.0
            m.avg_rtt_ms = session.handshake_rtt * 1000.0
            m.median_rtt_ms = session.handshake_rtt * 1000.0
            m.p95_rtt_ms = session.handshake_rtt * 1000.0
            m.srtt_ms = session.handshake_rtt * 1000.0
            m.rto_ms = m.srtt_ms * 2.0

        # Window Metrics
        if win_sizes:
            m.max_advertised_win_bytes = max(win_sizes)
            m.min_advertised_win_bytes = min(win_sizes)
            m.avg_advertised_win_bytes = sum(win_sizes) / len(win_sizes)

        m.retransmission_count = retrans_count
        m.fast_retransmission_count = fast_retrans_count
        m.timeout_retransmission_count = timeout_retrans_count
        m.duplicate_ack_count = dup_ack_count
        m.out_of_order_count = out_of_order_count
        m.zero_window_count = zero_win_count

        total_data_pkts = sum(1 for p in packets if p.payload_len > 0)
        if total_data_pkts > 0:
            m.retransmission_rate_pct = (retrans_count / total_data_pkts) * 100.0
            m.packet_loss_rate_pct = min(100.0, (retrans_count / (total_data_pkts + retrans_count)) * 100.0)
        elif session.packet_count > 0:
            m.retransmission_rate_pct = (retrans_count / session.packet_count) * 100.0
            m.packet_loss_rate_pct = m.retransmission_rate_pct

    def _analyze_generic_dynamics(self, session: ConversationSession, m: SessionMetrics) -> None:
        """Generic analysis for UDP, ICMP, and non-TCP flows."""
        packets = session.packets
        if len(packets) < 2:
            return

        inter_arrival_times = []
        for i in range(1, len(packets)):
            dt = packets[i].timestamp - packets[i - 1].timestamp
            inter_arrival_times.append(dt * 1000.0)

        if inter_arrival_times:
            m.min_rtt_ms = min(inter_arrival_times)
            m.max_rtt_ms = max(inter_arrival_times)
            m.avg_rtt_ms = sum(inter_arrival_times) / len(inter_arrival_times)
            m.median_rtt_ms = m.avg_rtt_ms
            m.p95_rtt_ms = m.max_rtt_ms

            # Estimate jitter from inter-arrival variance
            diffs = [abs(inter_arrival_times[i] - inter_arrival_times[i - 1]) for i in range(1, len(inter_arrival_times))]
            if diffs:
                m.avg_jitter_ms = sum(diffs) / len(diffs)
                m.max_jitter_ms = max(diffs)

    def _generate_throughput_timeseries(self, session: ConversationSession, m: SessionMetrics) -> None:
        """Buckets packets into time intervals to calculate rolling wire & goodput mbps."""
        packets = session.packets
        if not packets:
            return

        duration = max(0.001, session.duration)

        # Dynamic bin interval: target around 30-100 data points for responsive graphs
        if self.default_bin_interval:
            interval = self.default_bin_interval
        elif duration <= 1.0:
            interval = 0.05  # 50ms bins
        elif duration <= 10.0:
            interval = 0.2   # 200ms bins
        elif duration <= 60.0:
            interval = 0.5   # 500ms bins
        else:
            interval = max(1.0, duration / 100.0)

        num_bins = int(math.ceil(duration / interval)) + 1
        wire_bins = [0] * num_bins
        goodput_bins = [0] * num_bins
        pkt_bins = [0] * num_bins

        t0 = session.start_time
        for pkt in packets:
            bin_idx = min(num_bins - 1, int((pkt.timestamp - t0) / interval))
            wire_bins[bin_idx] += pkt.wire_len
            goodput_bins[bin_idx] += pkt.payload_len
            pkt_bins[bin_idx] += 1

        peak_wire = 0.0
        peak_goodput = 0.0
        timeseries = []

        for b in range(num_bins):
            t_center = (b + 0.5) * interval
            if t_center > duration + interval:
                break
            w_mbps = (wire_bins[b] * 8) / (interval * 1e6)
            g_mbps = (goodput_bins[b] * 8) / (interval * 1e6)
            pps = pkt_bins[b] / interval

            peak_wire = max(peak_wire, w_mbps)
            peak_goodput = max(peak_goodput, g_mbps)

            timeseries.append({
                "time": round(t_center, 4),
                "wire_mbps": round(w_mbps, 3),
                "goodput_mbps": round(g_mbps, 3),
                "pps": round(pps, 1),
                "wire_bytes": wire_bins[b],
                "payload_bytes": goodput_bins[b],
                "packets": pkt_bins[b],
            })

        m.timeseries_throughput = timeseries
        m.peak_wire_throughput_mbps = peak_wire
        m.peak_goodput_mbps = peak_goodput

        if m.avg_wire_throughput_mbps > 0:
            m.burstiness_factor = m.peak_wire_throughput_mbps / m.avg_wire_throughput_mbps
        else:
            m.burstiness_factor = 1.0
