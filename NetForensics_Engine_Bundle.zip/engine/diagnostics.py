"""
Forensic Diagnostic Engine - Automated Root-Cause Bottleneck Classifier
Distinguishes mathematically between Link Saturation, Router Packet Loss,
Propagation Delay, Bufferbloat, Receiver Window Throttling, and Connection Resets.
"""

from enum import Enum
from typing import List, Dict, Any, Optional
from .metrics import SessionMetrics
from .demux import ConversationSession


class BottleneckVerdict(str, Enum):
    OPTIMAL_HEALTHY = "OPTIMAL_HEALTHY"
    LINK_SATURATION = "LINK_SATURATION"
    PACKET_LOSS_ROUTER_DROP = "PACKET_LOSS_ROUTER_DROP"
    HIGH_PROPAGATION_DELAY = "HIGH_PROPAGATION_DELAY"
    BUFFERBLOAT = "BUFFERBLOAT"
    RECEIVER_WINDOW_THROTTLING = "RECEIVER_WINDOW_THROTTLING"
    CONNECTION_TERMINATION_RESET = "CONNECTION_TERMINATION_RESET"
    UNSTABLE_JITTER = "UNSTABLE_JITTER"


class SeverityLevel(str, Enum):
    OPTIMAL = "HEALTHY"
    INFO = "INFO"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"


class DiagnosisReport:
    """Structured forensic report with evidence chain and mathematical proofs."""

    def __init__(self, session_id: str):
        self.session_id: str = session_id
        self.primary_verdict: BottleneckVerdict = BottleneckVerdict.OPTIMAL_HEALTHY
        self.severity: SeverityLevel = SeverityLevel.OPTIMAL
        self.confidence_score: float = 0.95
        self.headline: str = "Healthy Transmission Flow"
        self.summary: str = "The network connection performed efficiently with nominal latency and zero packet loss."
        self.mathematical_proof: str = ""
        self.evidence_chain: List[Dict[str, Any]] = []
        self.root_cause_factors: List[Dict[str, str]] = []
        self.remediation_steps: List[str] = []

    def to_dict(self) -> Dict[str, Any]:
        return {
            "session_id": self.session_id,
            "verdict": self.primary_verdict.value,
            "severity": self.severity.value,
            "confidence_score": round(self.confidence_score, 2),
            "headline": self.headline,
            "summary": self.summary,
            "mathematical_proof": self.mathematical_proof,
            "evidence_chain": self.evidence_chain,
            "root_cause_factors": self.root_cause_factors,
            "remediation_steps": self.remediation_steps,
        }


class ForensicDiagnosticEngine:
    """Evaluates multi-metric decision boundaries to generate actionable forensic verdicts."""

    def __init__(self):
        pass

    def diagnose(self, session: ConversationSession, metrics: SessionMetrics) -> DiagnosisReport:
        """Runs the diagnostic rule and statistical classifier on session metrics."""
        report = DiagnosisReport(session.session_id)

        # Extract primary metrics
        loss_pct = metrics.packet_loss_rate_pct
        retrans_pct = metrics.retransmission_rate_pct
        min_rtt = metrics.min_rtt_ms
        max_rtt = metrics.max_rtt_ms
        avg_rtt = metrics.avg_rtt_ms
        handshake_rtt = metrics.handshake_rtt_ms or min_rtt
        jitter = metrics.avg_jitter_ms
        zero_wins = metrics.zero_window_count
        retrans_count = metrics.retransmission_count
        fast_retrans = metrics.fast_retransmission_count
        timeout_retrans = metrics.timeout_retransmission_count
        dup_acks = metrics.duplicate_ack_count
        wire_mbps = metrics.avg_wire_throughput_mbps
        efficiency = metrics.goodput_efficiency_pct
        bufferbloat = metrics.bufferbloat_index_pct
        has_reset = session.has_reset

        # Build Diagnostic Evaluation Matrix

        # Check 1: Receiver Zero-Window Throttling
        if zero_wins > 0:
            report.primary_verdict = BottleneckVerdict.RECEIVER_WINDOW_THROTTLING
            report.severity = SeverityLevel.CRITICAL
            report.confidence_score = 0.98
            report.headline = "Receiver Throttling (TCP Zero-Window Starvation)"
            report.summary = (
                f"The receiver advertised a Zero Window (win=0) {zero_wins} time(s). "
                "The sender was forced to stall transmission because the destination host's application/socket "
                "buffer became completely full and failed to drain incoming payload."
            )
            report.mathematical_proof = (
                f"TCP Advertised Window reached 0 bytes. Zero-Window Events: {zero_wins}. "
                f"While link loss was {loss_pct:.2f}%, Goodput was throttled down by TCP flow control."
            )
            report.root_cause_factors.append({
                "factor": "Receiver Buffer Depletion",
                "detail": "Application on the destination machine is CPU bound or slow at reading from the TCP socket buffer."
            })
            report.remediation_steps.extend([
                "Increase the receiver's OS TCP receive buffer (e.g., net.ipv4.tcp_rmem in Linux).",
                "Profile the receiving application for slow I/O or single-threaded socket blocking.",
                "Ensure TCP Window Scaling (RFC 7323) is enabled on both client and server."
            ])

        # Check 2: Packet Loss / Router Congestion Drops
        elif retrans_pct >= 1.0 or retrans_count >= 1 or dup_acks >= 2:
            effective_loss_rate = max(retrans_pct, (retrans_count / max(1, len(session.packets))) * 100.0)
            report.primary_verdict = BottleneckVerdict.PACKET_LOSS_ROUTER_DROP
            report.severity = SeverityLevel.CRITICAL if effective_loss_rate >= 5.0 else SeverityLevel.WARNING
            report.confidence_score = min(0.99, 0.80 + (effective_loss_rate / 20.0))
            report.headline = f"Network Packet Loss & Retransmission Degradation ({effective_loss_rate:.1f}% Retransmit Rate)"
            report.summary = (
                f"Packet loss detected with {retrans_count} retransmitted segment(s) "
                f"({fast_retrans} fast retransmits triggered by {dup_acks} duplicate ACKs, "
                f"{timeout_retrans} RTO timeout retransmits). Intermediate routing nodes or interfaces "
                "are dropping frames due to buffer overflow, tail-drop, or physical line errors."
            )
            report.mathematical_proof = (
                f"Retransmission Count = {retrans_count} ({effective_loss_rate:.2f}% of flow packets). "
                f"Duplicate ACKs Observed = {dup_acks}. Fast Retransmits = {fast_retrans}. Timeout Retransmits = {timeout_retrans}. "
                f"Goodput Efficiency penalized to {efficiency:.1f}% (Overhead: {metrics.protocol_overhead_pct:.1f}%)."
            )
            report.root_cause_factors.append({
                "factor": "Queue Overflow / Tail Drop",
                "detail": f"Observed {dup_acks} Duplicate ACKs indicating out-of-sequence delivery and missing segments in transit."
            })
            if timeout_retrans > 0:
                report.root_cause_factors.append({
                    "factor": "RTO Expiration",
                    "detail": f"{timeout_retrans} packet(s) experienced complete loss without fast-recovery, causing sender to stall for {metrics.rto_ms:.1f}ms RTO."
                })
            report.remediation_steps.extend([
                "Inspect intermediate switch/router egress queues for tail-drops and CRC frame check sequence (FCS) errors.",
                "Enable Explicit Congestion Notification (ECN - RFC 3168) on edge routers.",
                "Switch to modern BBR (Bottleneck Bandwidth and RTT) congestion control algorithm to resist loss-induced throughput collapses."
            ])

        # Check 3: Bufferbloat (Queue delay swelling under throughput)
        elif bufferbloat >= 150.0 and max_rtt >= 80.0:
            report.primary_verdict = BottleneckVerdict.BUFFERBLOAT
            report.severity = SeverityLevel.WARNING
            report.confidence_score = 0.90
            report.headline = f"Severe Bufferbloat Detected (Latency inflated by +{bufferbloat:.0f}%)"
            report.summary = (
                f"Connection baseline RTT is {min_rtt:.1f}ms, but under load the round-trip latency surged "
                f"to {max_rtt:.1f}ms (+{bufferbloat:.0f}% bloat). Unmanaged oversized router/modem packet buffers "
                "are queueing packets excessively instead of signaling congestion."
            )
            report.mathematical_proof = (
                f"Bufferbloat Index = ((Max RTT ({max_rtt:.1f}ms) - Min RTT ({min_rtt:.1f}ms)) / Min RTT ({min_rtt:.1f}ms)) × 100% "
                f"= +{bufferbloat:.1f}%. Excess Queue Delay = {max_rtt - min_rtt:.1f}ms."
            )
            report.root_cause_factors.append({
                "factor": "Oversized Unmanaged FIFO Queues",
                "detail": "Network hardware buffers are absorbing burst packets without dropping or marking, creating massive artificial delay."
            })
            report.remediation_steps.extend([
                "Deploy Active Queue Management (AQM) such as CAKE or FQ-CoDel on intermediate routers/gateways.",
                "Enable BBR congestion control on the sending host to prevent buffer queue filling."
            ])

        # Check 4: High Propagation Delay / Physical Distance
        elif handshake_rtt >= 120.0 or min_rtt >= 120.0:
            report.primary_verdict = BottleneckVerdict.HIGH_PROPAGATION_DELAY
            report.severity = SeverityLevel.WARNING
            report.confidence_score = 0.94
            report.headline = f"Physical Distance / Propagation Delay Bottleneck (Base RTT = {min_rtt:.1f}ms)"
            report.summary = (
                f"The physical distance or medium propagation time imposes an immutable minimum RTT of {min_rtt:.1f}ms "
                f"(TCP 3-way handshake established at {handshake_rtt:.1f}ms). Network throughput is strictly bounded "
                f"by the Bandwidth-Delay Product (BDP = {metrics.bdp_bytes / 1024:.1f} KB)."
            )
            report.mathematical_proof = (
                f"Minimum RTT = {min_rtt:.1f}ms (Handshake RTT = {handshake_rtt:.1f}ms). "
                f"Max Theoretical Throughput with current window = (TCP_Win / RTT) = "
                f"({metrics.max_advertised_win_bytes} bytes / {min_rtt / 1000.0:.3f}s) × 8 = "
                f"{(metrics.max_advertised_win_bytes * 8) / (min_rtt * 1000.0):.2f} Mbps."
            )
            report.root_cause_factors.append({
                "factor": "Speed of Light in Fiber / Geostationary Distance",
                "detail": "Geographical separation (e.g. intercontinental transit or satellite uplink) creates high propagation delay."
            })
            report.remediation_steps.extend([
                "Enable large TCP Window Scaling (RFC 7323) to increase maximum window beyond 64KB.",
                "Utilize HTTP/3 (QUIC) or Multipath TCP to minimize handshake round trips (0-RTT).",
                "Deploy Edge CDN / Reverse Proxies closer to the client geography."
            ])

        # Check 5: Connection Reset / Abnormal Termination
        elif has_reset:
            report.primary_verdict = BottleneckVerdict.CONNECTION_TERMINATION_RESET
            report.severity = SeverityLevel.WARNING
            report.confidence_score = 0.92
            report.headline = "Abnormal Connection Reset (TCP RST)"
            report.summary = "The TCP session was forcibly closed by a TCP RST (Reset) segment before graceful FIN teardown."
            report.mathematical_proof = "TCP RST flag encountered in flow. Session transitioned to RESET state."
            report.remediation_steps.append("Check firewall state timeouts or application unhandled exception crashes.")

        # Check 6: Link Saturation / High Utilization
        elif wire_mbps >= 50.0 and retrans_pct < 1.0:
            report.primary_verdict = BottleneckVerdict.LINK_SATURATION
            report.severity = SeverityLevel.INFO
            report.confidence_score = 0.88
            report.headline = f"High Link Saturation ({wire_mbps:.1f} Mbps Sustained)"
            report.summary = (
                f"The flow utilized high wire bandwidth ({wire_mbps:.1f} Mbps avg, {metrics.peak_wire_throughput_mbps:.1f} Mbps peak) "
                f"with excellent Goodput efficiency ({efficiency:.1f}%) and near-zero packet loss ({loss_pct:.2f}%)."
            )
            report.mathematical_proof = (
                f"Sustained Throughput = {wire_mbps:.2f} Mbps. Burstiness Factor = {metrics.burstiness_factor:.2f}. "
                f"Goodput = {metrics.avg_goodput_mbps:.2f} Mbps."
            )
            report.remediation_steps.append("To scale further, increase physical link bandwidth (e.g. 10G uplink) or link aggregation (LACP).")

        # Healthy Baseline
        else:
            report.primary_verdict = BottleneckVerdict.OPTIMAL_HEALTHY
            report.severity = SeverityLevel.OPTIMAL
            report.confidence_score = 0.95
            report.headline = "Optimal Performance (Low Latency, Zero Loss)"
            report.summary = (
                f"Nominal network operation with {loss_pct:.2f}% packet loss, {min_rtt:.1f}ms RTT, and {efficiency:.1f}% goodput efficiency."
            )
            report.mathematical_proof = (
                f"Loss Rate = {loss_pct:.2f}%. Retransmissions = 0. Avg RTT = {avg_rtt:.2f}ms. Goodput Ratio = {efficiency:.1f}%."
            )
            report.remediation_steps.append("No remediation required. Network path is functioning optimally.")

        # Compile chronological forensic evidence chain
        self._build_evidence_chain(session, metrics, report)

        return report

    def _build_evidence_chain(self, session: ConversationSession, metrics: SessionMetrics, report: DiagnosisReport) -> None:
        """Extracts key packet milestones into an audit log evidence chain."""
        chain = []
        packets = session.packets

        if not packets:
            return

        # Milestone: Session Start
        p1 = packets[0]
        chain.append({
            "step": 1,
            "packet_index": p1.index,
            "rel_time": round(p1.rel_time, 4),
            "event": "Session Ingestion & 5-Tuple Demux",
            "details": f"Initiated {session.proto} flow between {session.client_endpoint} and {session.server_endpoint}.",
            "badge": "START"
        })

        # Milestone: Handshake RTT
        if session.handshake_rtt is not None:
            chain.append({
                "step": len(chain) + 1,
                "packet_index": session.packets[min(2, len(packets) - 1)].index,
                "rel_time": round(session.handshake_ack_time - session.start_time, 4) if session.handshake_ack_time else 0.001,
                "event": "TCP 3-Way Handshake Established",
                "details": f"Handshake RTT = {session.handshake_rtt * 1000.0:.2f}ms. Client MSS: {session.client_mss}, Server MSS: {session.server_mss}.",
                "badge": "HANDSHAKE"
            })

        # Milestone: Anomalies (Retransmissions, Zero Windows, RSTs)
        anomaly_count = 0
        for pkt in packets:
            if pkt.forensic_tags and anomaly_count < 10:
                tag_str = ", ".join(pkt.forensic_tags)
                chain.append({
                    "step": len(chain) + 1,
                    "packet_index": pkt.index,
                    "rel_time": round(pkt.rel_time, 4),
                    "event": f"Forensic Anomaly: {tag_str}",
                    "details": f"Seq={pkt.tcp_seq}, Ack={pkt.tcp_ack}, Win={pkt.tcp_win}, Payload={pkt.payload_len}B. ({pkt.info})",
                    "badge": "ANOMALY" if "Retransmission" in tag_str or "Zero Window" in tag_str else "WARN"
                })
                anomaly_count += 1

        # Milestone: Final Forensic Verdict
        chain.append({
            "step": len(chain) + 1,
            "packet_index": packets[-1].index,
            "rel_time": round(packets[-1].rel_time, 4),
            "event": f"Root-Cause Forensic Verdict: {report.headline}",
            "details": f"Analyzed {len(packets)} frames ({metrics.total_wire_bytes:,} bytes). Confidence: {report.confidence_score * 100:.0f}%.",
            "badge": "VERDICT"
        })

        report.evidence_chain = chain
