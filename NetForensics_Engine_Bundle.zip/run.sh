#!/usr/bin/env bash
# NetForensics Startup Script
set -e

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$DIR"

# Ensure venv exists
if [ ! -d "$DIR/venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv "$DIR/venv"
    "$DIR/venv/bin/pip" install --upgrade pip
    "$DIR/venv/bin/pip" install -r "$DIR/requirements.txt"
fi

# If arguments passed, forward to CLI
if [ "$#" -gt 0 ]; then
    exec "$DIR/venv/bin/python" "$DIR/cli.py" "$@"
else
    echo "================================================================="
    echo "  🔬 NetForensics Engine // Web Dashboard & API"
    echo "  Listening on: http://localhost:8000"
    echo "================================================================="
    exec "$DIR/venv/bin/python" "$DIR/cli.py" --serve --port 8000
fi
