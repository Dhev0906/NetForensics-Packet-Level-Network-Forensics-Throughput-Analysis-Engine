# 🔬 Packet-Level Forensics & Throughput Analysis Engine (NetForensics)

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![FastAPI](https://img.shields.io/badge/backend-FastAPI-009688.svg)](https://fastapi.tiangolo.com/)
[![TailwindCSS](https://img.shields.io/badge/frontend-TailwindCSS%20%2B%20Chart.js-38bdf8.svg)](https://tailwindcss.com/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

> An automated forensic network diagnostic engine that ingests, decodes, and mathematically models raw `.pcap` packet streams to pinpoint the root cause of network underperformance down to the exact byte.

---

## 📖 Theoretical Problem & Motivation

When a network connection is slow or failing, traditional monitoring tools (ping, speed tests, or high-level SNMP counters) only report symptoms—such as "high latency" or "low bandwidth". They cannot tell you **why** or **where** the bottleneck occurred.

Is the degradation caused by:
1. **A Saturated Link (Throughput)** — Available capacity fully exhausted?
2. **A Dropping Switch/Router (Packet Loss)** — Queue buffer overflow, tail-drops, or FCS line errors?
3. **Physical Distance / Propagation Delay (Latency)** — Fundamental speed-of-light limits over transcontinental fiber or satellite uplinks?
4. **Bufferbloat** — Oversized unmanaged FIFO queues swelling round-trip times under active traffic?
5. **Receiver Socket Buffer Starvation (Flow Control)** — A slow application causing TCP Zero-Window stalls?

**NetForensics** answers this by bypassing high-level abstractions, parsing the raw wire packets, and applying RFC-standard networking algorithms directly on reconstructed 5-tuple conversations.

---

## 🏗️ Architecture & Execution Flow

```
   ┌─────────────────────────────────────────────────────────────┐
   │             Raw Packet Capture (.pcap / .pcapng)            │
   └──────────────────────────────┬──────────────────────────────┘
                                  ▼
   ┌─────────────────────────────────────────────────────────────┐
   │ 1. Data Ingestion & Layer Decoder (engine/parser.py)        │
   │    - Ethernet II / Linux SLL / VLAN 802.1Q                  │
   │    - IPv4 / IPv6 / ARP / ICMP                               │
   │    - TCP (MSS, Window Scale, SACK, Timestamps) / UDP / DNS  │
   │    - Raw Byte Payload & Hex Inspection Structure            │
   └──────────────────────────────┬──────────────────────────────┘
                                  ▼
   ┌─────────────────────────────────────────────────────────────┐
   │ 2. 5-Tuple Demultiplexer & Session Reconstructor (demux.py) │
   │    - Groups packets by (SrcIP, SrcPort, DstIP, DstPort, Pr) │
   │    - Tracks TCP State Machine (SYN, ESTABLISHED, FIN, RST)  │
   │    - Directional byte accounting (Client ⇄ Server)          │
   └──────────────────────────────┬──────────────────────────────┘
                                  ▼
   ┌─────────────────────────────────────────────────────────────┐
   │ 3. Mathematical Computation Engine (metrics.py)             │
   │    - Wire Throughput vs Application Goodput Efficiency      │
   │    - RFC 6298 Smoothed RTT (SRTT), RTTVAR & RTO Calculation │
   │    - RFC 3550 Latency Jitter & Bufferbloat Index            │
   │    - Sequence Space Tracking: Fast Retransmits vs Timeouts  │
   │    - tcptrace Time-Sequence Progression & TCP Window Space  │
   └──────────────────────────────┬──────────────────────────────┘
                                  ▼
   ┌─────────────────────────────────────────────────────────────┐
   │ 4. Automated Forensic Diagnostic Engine (diagnostics.py)    │
   │    - Root-Cause Bottleneck Classifier                       │
   │    - Mathematical Proofs & Evidence Audit Log               │
   │    - Actionable Engineering Remediation Advice              │
   └──────────────────────────────┬──────────────────────────────┘
                                  ▼
          ┌───────────────────────┴───────────────────────┐
          ▼                                               ▼
┌─────────────────────────────────┐   ┌─────────────────────────────────┐
│ Interactive Web Dashboard       │   │ Rich CLI & Automated Reporting  │
│ - Wireshark-Grade 3-Pane View   │   │ - Color-coded diagnostic tables │
│ - Chart.js Telemetry & tcptrace │   │ - PDF Forensic Dossier export   │
│ - Synthetic Scenario Simulator  │   │ - Markdown Audit Report export  │
└─────────────────────────────────┘   └─────────────────────────────────┘
```

---

## 📐 Mathematical Models Implemented

### 1. Throughput & Goodput Formulation
$$\text{Wire Throughput (Mbps)} = \frac{\sum \text{Frame Bytes} \times 8}{\Delta T \times 10^6}$$
$$\text{Application Goodput (Mbps)} = \frac{\sum \text{Payload Bytes} \times 8}{\Delta T \times 10^6}$$
$$\text{Goodput Efficiency (\%)} = \left( \frac{\sum \text{Payload Bytes}}{\sum \text{Wire Bytes}} \right) \times 100$$

### 2. RFC 6298 Smoothed Round-Trip Time (SRTT) & RTO
Upon receiving non-retransmitted ACK samples $R'$:
$$SRTT \leftarrow (1 - \alpha) \cdot SRTT + \alpha \cdot R' \quad (\alpha = 0.125)$$
$$RTTVAR \leftarrow (1 - \beta) \cdot RTTVAR + \beta \cdot |SRTT - R'| \quad (\beta = 0.25)$$
$$RTO = SRTT + \max(G, 4 \cdot RTTVAR)$$

### 3. RFC 3550 Latency Jitter
$$D(i, j) = (R_j - S_j) - (R_i - S_i)$$
$$J_i = J_{i-1} + \frac{|D(i, j)| - J_{i-1}}{16}$$

### 4. Bufferbloat Expansion Index
$$\text{Bufferbloat Index (\%)} = \left( \frac{\text{Max RTT} - \text{Min RTT}}{\text{Min RTT}} \right) \times 100$$

### 5. Bandwidth-Delay Product (BDP)
$$\text{BDP (Bytes)} = \left( \frac{\text{Throughput (bps)}}{8} \right) \times \text{Min RTT (sec)}$$

---

## 🚀 Quickstart & Setup

### Prerequisites
- Python 3.10+
- `pip` / `venv`

### 1. Clone or Open Project
```bash
cd /home/b47m4n/Projects/Dhev
```

### 2. Start the Interactive Web Dashboard
Run the all-in-one runner script:
```bash
./run.sh
```
Or start manually via Python virtualenv:
```bash
./venv/bin/python cli.py --serve --port 8000
```
Then open your browser to **[http://localhost:8000](http://localhost:8000)**.

---

## 💻 CLI Usage

The engine includes a high-contrast terminal interface with ASCII tables and diagnostic verdicts:

```bash
# Analyze a preset scenario
./run.sh --preset packet_loss_drop

# Analyze any external custom PCAP file
./run.sh --pcap /path/to/capture.pcap

# Export a formal PDF forensic dossier and Markdown audit report
./run.sh --preset bufferbloat_queue --export-pdf report.pdf --export-md report.md

# Generate all synthetic test scenario PCAPs
./run.sh --generate-presets
```

---

## 🧪 Built-in Test Scenarios

The engine includes 6 pre-built diagnostic scenarios to validate root-cause classification:

| Scenario ID | Name | Injected Network Condition | Diagnostic Verdict |
| :--- | :--- | :--- | :--- |
| `clean_gigabit` | Gigabit Clean Transfer | Zero loss, 2ms RTT, WScale=7, sustained 900+ Mbps | `OPTIMAL_HEALTHY` |
| `packet_loss_drop` | Router Queue Drops | In-flight segment drops, 3× Dup ACKs, Fast Retransmit, RTO timeout | `PACKET_LOSS_ROUTER_DROP` |
| `high_latency_satellite` | Satellite Link | 640ms propagation delay, BDP throughput bottleneck | `HIGH_PROPAGATION_DELAY` |
| `bufferbloat_queue` | Switch Bufferbloat | RTT swells from 15ms to 420ms (+2700%) under active queue load | `BUFFERBLOAT` |
| `zero_window_receiver` | Zero-Window Throttling | Socket buffer exhaustion, `win=0`, Zero-Window probes & updates | `RECEIVER_WINDOW_THROTTLING` |
| `multiflow_web` | Enterprise Traffic | Concurrent DNS lookups (UDP 53), HTTP web streams, ICMP echo | `OPTIMAL_HEALTHY` |

---

## 🖥️ Web Dashboard Highlights

1. **KPI Telemetry Ribbon**: Real-time summary of Decoded Frames, Wire Volume, Wire Mbps, Goodput Efficiency %, Loss Rate, SRTT Latency, and Demuxed Flows.
2. **Root-Cause Diagnostic Command Center**: Color-coded severity badge (CRITICAL, WARNING, HEALTHY), plain-language summary, mathematical proof box, identified root-cause vectors, and actionable engineering remediation steps.
3. **Interactive Charting Suite**:
   - **Throughput & Goodput**: Dynamic timeseries comparing Wire Rate vs Payload vs Packet Rate.
   - **tcptrace Time-Sequence Ladder**: Sequence progress, ACK line, Fast Retransmits (red triangles), and Duplicate ACKs (yellow diamonds).
   - **Delay & SRTT Dynamics**: Sampled RTT, RFC 6298 SRTT, and RTO boundary curve.
   - **Protocol & Frame Size Distribution**: Donut chart of protocol breakdown and frame length histogram.
4. **5-Tuple Conversation Demux Matrix**: Sortable table of all reconstructed sessions. Clicking any flow instantly focuses all telemetry charts on that isolated session.
5. **Wireshark-Grade 3-Pane Deep Packet Inspector**:
   - Filterable & searchable packet stream with anomaly tags (`[Retransmission]`, `[Dup ACK #3]`, `[TCP Zero Window]`).
   - Expandable protocol tree breakdown (Ethernet, IPv4/IPv6, TCP/UDP/ICMP, Payload).
   - Dual Hexadecimal & ASCII Byte viewer with offset indexing.
6. **Synthetic Scenario Simulator**: Built-in modal allowing custom injection of loss rate %, latency, bufferbloat multipliers, and zero-window stalls to test custom scenarios on the fly.
7. **Report Exports**: One-click download of PDF Investigation Dossiers, Markdown Audit Reports, or Raw JSON Telemetry.

---

## 📁 Repository Structure

```
/home/b47m4n/Projects/Dhev/
├── README.md                      # Academic & technical documentation
├── requirements.txt               # Dependencies (FastAPI, dpkt, scapy, reportlab, etc.)
├── run.sh                         # Unified startup & CLI wrapper script
├── cli.py                         # Standalone terminal CLI forensic tool
├── engine/                        # Core algorithmic engine
│   ├── __init__.py                # Package exports
│   ├── parser.py                  # PCAP/PCAPNG header and protocol decoder
│   ├── demux.py                   # 5-tuple session reconstructor & TCP state machine
│   ├── metrics.py                 # Throughput, Goodput, RTT, SRTT, Jitter & tcptrace math
│   ├── diagnostics.py             # Root-cause bottleneck classification & evidence audit
│   ├── generator.py               # Synthetic PCAP scenario builder
│   ├── report_gen.py              # PDF and Markdown forensic report generator
│   └── pipeline.py                # Pipeline coordinator
├── web/                           # Web application
│   ├── app.py                     # FastAPI REST API & static file server
│   └── static/                    # Frontend assets
│       ├── index.html             # Dashboard UI
│       ├── css/style.css          # Dark glassmorphism & telemetry styles
│       └── js/
│           ├── app.js             # State management, packet inspector & UI handlers
│           └── charts.js          # Chart.js telemetry visualizers
└── scenarios/                     # Pre-generated synthetic PCAP test files
```

---

## 📜 License
MIT License. Built for rigorous network performance diagnostics, computer networking education, and packet-level forensic research.
