#!/usr/bin/env python3
"""
NetForensics CLI - Command Line Forensic Network Diagnostics & Throughput Analyzer
"""

import sys
import os
import argparse
from typing import Optional

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich import box

from engine.pipeline import ForensicsPipeline
from engine.generator import ScenarioGenerator
from engine.report_gen import ForensicReportGenerator


console = Console()


def print_banner():
    console.print(Panel(
        Text("🔬 NETFORENSICS ENGINE // Packet-Level Forensics & Throughput Analyzer\n"
             "Automated 5-Tuple Demuxing, Mathematical Modeling & Root-Cause Bottleneck Classifier",
             justify="center", style="bold cyan"),
        box=box.DOUBLE_EDGE,
        border_style="bright_blue"
    ))


def analyze_and_print(pcap_path: str, export_md: Optional[str] = None, export_pdf: Optional[str] = None):
    pipeline = ForensicsPipeline()

    with console.status(f"[bold green]Decoding {os.path.basename(pcap_path)} and computing mathematical metrics...", spinner="dots"):
        result = pipeline.process_pcap(pcap_path)

    summary = result.get("summary", {})
    sessions = result.get("sessions", [])
    primary_diag = result.get("primary_diagnosis", {})

    # 1. Summary Telemetry Table
    sum_table = Table(title=f"📊 Ingestion & Telemetry Summary: {os.path.basename(pcap_path)}", box=box.ROUNDED, border_style="cyan")
    sum_table.add_column("Metric", style="bold white", width=26)
    sum_table.add_column("Measured Value", style="bold green", width=22)
    sum_table.add_column("Metric", style="bold white", width=26)
    sum_table.add_column("Measured Value", style="bold green", width=22)

    sum_table.add_row(
        "Total Captured Frames", f"{summary.get('total_packets', 0):,}",
        "Duration Span", f"{summary.get('duration_sec', 0.0):.4f} sec"
    )
    sum_table.add_row(
        "Total Wire Data", f"{summary.get('total_wire_bytes', 0):,} bytes",
        "Application Goodput", f"{summary.get('total_payload_bytes', 0):,} bytes"
    )
    sum_table.add_row(
        "Avg Wire Bandwidth", f"{summary.get('avg_wire_mbps', 0.0):.2f} Mbps",
        "Avg Goodput Rate", f"{summary.get('avg_goodput_mbps', 0.0):.2f} Mbps"
    )
    sum_table.add_row(
        "Goodput Efficiency", f"{summary.get('goodput_efficiency_pct', 0.0):.1f}%",
        "Protocol Overhead", f"{summary.get('protocol_overhead_pct', 0.0):.1f}%"
    )
    sum_table.add_row(
        "Packet Loss Rate", f"{summary.get('packet_loss_rate_pct', 0.0):.2f}%",
        "Retransmissions", f"{summary.get('total_retransmissions', 0)} pkts"
    )
    sum_table.add_row(
        "Duplicate ACKs", f"{summary.get('total_duplicate_acks', 0)} frames",
        "Smoothed Latency (SRTT)", f"{summary.get('avg_rtt_ms', 0.0):.2f} ms"
    )
    console.print(sum_table)
    console.print()

    # 2. Diagnostic Root-Cause Verdict Panel
    sev = primary_diag.get("severity", "HEALTHY")
    sev_style = "bold red" if sev == "CRITICAL" else "bold yellow" if sev == "WARNING" else "bold green"

    verdict_text = Text()
    verdict_text.append(f"ROOT-CAUSE VERDICT: {primary_diag.get('verdict')}\n", style=f"{sev_style} underline")
    verdict_text.append(f"Severity: {sev} | Confidence: {primary_diag.get('confidence_score', 0.95)*100:.0f}%\n\n", style="bold white")
    verdict_text.append(f"{primary_diag.get('headline')}\n\n", style="bold cyan")
    verdict_text.append(f"{primary_diag.get('summary')}\n\n", style="white")

    if primary_diag.get("mathematical_proof"):
        verdict_text.append(f"Mathematical Wire Proof:\n{primary_diag.get('mathematical_proof')}\n", style="italic bright_cyan")

    console.print(Panel(verdict_text, title="🚨 Forensic Root-Cause Diagnostic Verdict", box=box.DOUBLE_EDGE, border_style=sev_style.split()[-1]))
    console.print()

    # 3. Demultiplexed Conversations Table
    if sessions:
        sess_table = Table(title="🔀 Demultiplexed Conversation Sessions (5-Tuples)", box=box.ROUNDED, border_style="blue")
        sess_table.add_column("Proto", style="cyan", width=8)
        sess_table.add_column("Client Endpoint", style="white", width=22)
        sess_table.add_column("Server Endpoint", style="white", width=22)
        sess_table.add_column("Frames", justify="right", width=8)
        sess_table.add_column("Wire Vol", justify="right", width=10)
        sess_table.add_column("Throughput", justify="right", width=12)
        sess_table.add_column("Loss %", justify="right", width=8)
        sess_table.add_column("Avg RTT", justify="right", width=10)
        sess_table.add_column("Session Verdict", style="magenta", width=24)

        for s in sessions:
            loss_col = "[bold red]" if s.get("loss_rate_pct", 0) > 0 else "[green]"
            sess_table.add_row(
                s.get("proto", "TCP"),
                f"{s.get('client_ip')}:{s.get('client_port')}",
                f"{s.get('server_ip')}:{s.get('server_port')}",
                str(s.get("packet_count")),
                f"{s.get('total_wire_bytes')/(1024*1024):.2f}MB",
                f"{s.get('wire_mbps', 0.0):.2f}M",
                f"{loss_col}{s.get('loss_rate_pct', 0.0):.1f}%[/]",
                f"{s.get('avg_rtt_ms', 0.0):.1f}ms" if s.get("avg_rtt_ms") else "-",
                s.get("diagnosis_verdict", "OK")
            )
        console.print(sess_table)
        console.print()

    # 4. Actionable Remediation
    remediation = primary_diag.get("remediation_steps", [])
    if remediation:
        rem_table = Table(title="🛠️ Actionable Engineering Remediation", box=box.ROUNDED, border_style="yellow")
        rem_table.add_column("#", style="bold yellow", width=4)
        rem_table.add_column("Recommended Action", style="white")
        for i, step in enumerate(remediation, 1):
            rem_table.add_row(str(i), step)
        console.print(rem_table)
        console.print()

    # Export outputs if requested
    rep_gen = ForensicReportGenerator(pcap_path, result)
    if export_md:
        with open(export_md, "w", encoding="utf-8") as f:
            f.write(rep_gen.generate_markdown())
        console.print(f"[bold green]✓ Exported Markdown forensic report to:[/] {export_md}")

    if export_pdf:
        rep_gen.generate_pdf(export_pdf)
        console.print(f"[bold green]✓ Exported PDF forensic dossier to:[/] {export_pdf}")


def main():
    parser = argparse.ArgumentParser(description="Packet-Level Forensics & Throughput Analysis Engine")
    parser.add_argument("--pcap", "-p", type=str, help="Path to raw .pcap or .pcapng capture file")
    parser.add_argument("--preset", type=str, help="Analyze built-in scenario (clean_gigabit, packet_loss_drop, high_latency_satellite, bufferbloat_queue, zero_window_receiver, multiflow_web)")
    parser.add_argument("--export-md", type=str, help="Output Markdown report path")
    parser.add_argument("--export-pdf", type=str, help="Output PDF dossier path")
    parser.add_argument("--generate-presets", action="store_true", help="Generate all preset synthetic PCAPs")
    parser.add_argument("--serve", "-s", action="store_true", help="Launch interactive web dashboard")
    parser.add_argument("--port", type=int, default=8000, help="Web dashboard port (default: 8000)")

    args = parser.parse_args()
    print_banner()

    scenarios_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "scenarios")

    if args.generate_presets:
        console.print(f"[cyan]Generating preset scenarios in {scenarios_dir}...[/]")
        presets = ScenarioGenerator.generate_all_presets(scenarios_dir)
        console.print(f"[bold green]✓ Successfully generated {len(presets)} test scenarios![/]")
        return

    if args.serve:
        import uvicorn
        console.print(f"[bold green]🚀 Launching NetForensics Web Dashboard on http://localhost:{args.port}...[/]")
        uvicorn.run("web.app:app", host="0.0.0.0", port=args.port, reload=False)
        return

    target_pcap = None
    if args.preset:
        target_pcap = os.path.join(scenarios_dir, f"scenario_{args.preset}.pcap")
        if not os.path.exists(target_pcap):
            ScenarioGenerator.generate_all_presets(scenarios_dir)
    elif args.pcap:
        target_pcap = args.pcap
    else:
        # Default to clean gigabit preset if nothing specified
        target_pcap = os.path.join(scenarios_dir, "scenario_clean_gigabit.pcap")
        if not os.path.exists(target_pcap):
            ScenarioGenerator.generate_all_presets(scenarios_dir)

    if target_pcap and os.path.exists(target_pcap):
        analyze_and_print(target_pcap, export_md=args.export_md, export_pdf=args.export_pdf)
    else:
        console.print(f"[bold red]Error:[/] Capture file not found: {target_pcap}")
        parser.print_help()


if __name__ == "__main__":
    main()
