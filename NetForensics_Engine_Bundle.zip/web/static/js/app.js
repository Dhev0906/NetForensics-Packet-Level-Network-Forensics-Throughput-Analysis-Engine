/**
 * NetForensics Main Application Controller
 * Handles UI interactions, API communications, drill-down filtering, and Wireshark-grade 3-pane packet inspection.
 */

let state = {
    analysis: null,
    activeSessionId: null,
    activePacketIndex: null,
    filteredPackets: [],
    packetSearchTerm: '',
    packetProtoFilter: 'ALL',
    currentPage: 1,
    pageSize: 50,
};

document.addEventListener('DOMContentLoaded', async () => {
    initLucideIcons();
    setupEventListeners();
    await loadPresetsList();
    await loadCurrentAnalysis();
});

function initLucideIcons() {
    if (window.lucide) {
        lucide.createIcons();
    }
}

function setupEventListeners() {
    // File Upload Drag & Drop
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('fileInput');

    if (dropZone && fileInput) {
        dropZone.addEventListener('click', () => fileInput.click());
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('border-cyan-400', 'bg-slate-800/60');
        });
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('border-cyan-400', 'bg-slate-800/60');
        });
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('border-cyan-400', 'bg-slate-800/60');
            if (e.dataTransfer.files.length > 0) {
                handleFileUpload(e.dataTransfer.files[0]);
            }
        });

        fileInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                handleFileUpload(e.target.files[0]);
            }
        });
    }

    // Preset Selector
    const presetSelect = document.getElementById('presetSelect');
    if (presetSelect) {
        presetSelect.addEventListener('change', (e) => {
            if (e.target.value) {
                loadPreset(e.target.value);
            }
        });
    }

    // Packet search & filter
    const packetSearch = document.getElementById('packetSearch');
    if (packetSearch) {
        packetSearch.addEventListener('input', (e) => {
            state.packetSearchTerm = e.target.value.toLowerCase();
            state.currentPage = 1;
            filterAndRenderPackets();
        });
    }

    const protoFilter = document.getElementById('protoFilter');
    if (protoFilter) {
        protoFilter.addEventListener('change', (e) => {
            state.packetProtoFilter = e.target.value;
            state.currentPage = 1;
            filterAndRenderPackets();
        });
    }

    // Pagination
    document.getElementById('prevPageBtn')?.addEventListener('click', () => {
        if (state.currentPage > 1) {
            state.currentPage--;
            renderPacketTable();
        }
    });

    document.getElementById('nextPageBtn')?.addEventListener('click', () => {
        const totalPages = Math.ceil(state.filteredPackets.length / state.pageSize) || 1;
        if (state.currentPage < totalPages) {
            state.currentPage++;
            renderPacketTable();
        }
    });

    // Custom Generator Modal
    document.getElementById('openGeneratorBtn')?.addEventListener('click', () => {
        document.getElementById('generatorModal')?.classList.remove('hidden');
    });
    document.getElementById('closeGeneratorBtn')?.addEventListener('click', () => {
        document.getElementById('generatorModal')?.classList.add('hidden');
    });
    document.getElementById('generatorForm')?.addEventListener('submit', handleGenerateCustom);
}

/**
 * Loads list of available presets into selector
 */
async function loadPresetsList() {
    try {
        const res = await fetch('/api/presets');
        if (!res.ok) return;
        const presets = await res.json();
        const select = document.getElementById('presetSelect');
        if (!select) return;

        select.innerHTML = '<option value="" disabled selected>Select Diagnostic Scenario...</option>';
        presets.forEach(p => {
            const opt = document.createElement('option');
            opt.value = p.id;
            opt.textContent = `[${p.category}] ${p.name}`;
            select.appendChild(opt);
        });
    } catch (err) {
        console.error('Failed to load presets:', err);
    }
}

/**
 * Fetches current analysis on initial load
 */
async function loadCurrentAnalysis() {
    showLoading(true);
    try {
        const res = await fetch('/api/current');
        if (res.ok) {
            const data = await res.json();
            updateDashboard(data);
        }
    } catch (err) {
        console.error('Failed to load current analysis:', err);
    } finally {
        showLoading(false);
    }
}

/**
 * Triggers analysis of selected preset
 */
async function loadPreset(presetId) {
    showLoading(true);
    try {
        const res = await fetch(`/api/analyze/preset?preset_id=${presetId}`, { method: 'POST' });
        if (!res.ok) throw new Error('Preset analysis failed');
        const data = await res.json();
        updateDashboard(data);
    } catch (err) {
        alert(`Error loading scenario: ${err.message}`);
    } finally {
        showLoading(false);
    }
}

/**
 * Handles PCAP upload
 */
async function handleFileUpload(file) {
    showLoading(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
        const res = await fetch('/api/analyze/upload', {
            method: 'POST',
            body: formData
        });
        if (!res.ok) {
            const err = await res.json();
            throw new Error(err.detail || 'Upload failed');
        }
        const data = await res.json();
        updateDashboard(data);
    } catch (err) {
        alert(`Upload error: ${err.message}`);
    } finally {
        showLoading(false);
    }
}

/**
 * Handles custom scenario generator submission
 */
async function handleGenerateCustom(e) {
    e.preventDefault();
    const modal = document.getElementById('generatorModal');
    modal?.classList.add('hidden');
    showLoading(true);

    const body = {
        name: document.getElementById('genName')?.value || 'custom_scenario',
        packet_count: parseInt(document.getElementById('genPackets')?.value || '50'),
        loss_rate_pct: parseFloat(document.getElementById('genLoss')?.value || '0'),
        rtt_ms: parseFloat(document.getElementById('genRtt')?.value || '20'),
        bufferbloat_mult: parseFloat(document.getElementById('genBloat')?.value || '1'),
        zero_window: document.getElementById('genZeroWin')?.checked || false,
    };

    try {
        const res = await fetch('/api/generate/custom', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });
        if (!res.ok) throw new Error('Generation failed');
        const data = await res.json();
        updateDashboard(data);
    } catch (err) {
        alert(`Generation error: ${err.message}`);
    } finally {
        showLoading(false);
    }
}

/**
 * Primary UI State Synchronizer
 */
function updateDashboard(data) {
    state.analysis = data;
    state.activeSessionId = data.summary.dominant_session_id;

    // 1. Header Filename & Target
    document.getElementById('activeFilename').textContent = data.filename || 'capture.pcap';

    // 2. KPI Cards
    updateKPICards(data.summary);

    // 3. Diagnostic Verdict Panel
    updateDiagnosisPanel(data.primary_diagnosis);

    // 4. Evidence Timeline Chain
    updateEvidenceChain(data.primary_diagnosis.evidence_chain);

    // 5. Demuxed Sessions Table
    renderSessionsTable(data.sessions);

    // 6. Global & Session Charts
    updateChartsForActiveSession();

    // 7. Packet Inspector
    state.currentPage = 1;
    filterAndRenderPackets();

    if (data.packets && data.packets.length > 0) {
        selectPacket(data.packets[0].index);
    }

    initLucideIcons();
}

/**
 * Updates KPI Summary Ribbon
 */
function updateKPICards(summary) {
    document.getElementById('kpiPackets').textContent = summary.total_packets.toLocaleString();
    document.getElementById('kpiWireVolume').textContent = formatBytes(summary.total_wire_bytes);
    document.getElementById('kpiWireMbps').textContent = `${summary.avg_wire_mbps.toFixed(2)} Mbps`;
    document.getElementById('kpiGoodputEfficiency').textContent = `${summary.goodput_efficiency_pct.toFixed(1)}%`;
    document.getElementById('kpiLossRate').textContent = `${summary.packet_loss_rate_pct.toFixed(2)}%`;
    document.getElementById('kpiLossCount').textContent = `${summary.total_retransmissions} retrans, ${summary.total_duplicate_acks} dup ACKs`;
    document.getElementById('kpiSrtt').textContent = `${summary.avg_rtt_ms.toFixed(2)} ms`;
    document.getElementById('kpiSessions').textContent = `${summary.total_sessions} Flows`;
}

/**
 * Updates Root-Cause Diagnostic Verdict Card
 */
function updateDiagnosisPanel(diag) {
    const badge = document.getElementById('diagSeverityBadge');
    const verdict = document.getElementById('diagVerdict');
    const headline = document.getElementById('diagHeadline');
    const summary = document.getElementById('diagSummary');
    const proof = document.getElementById('diagProof');
    const confidence = document.getElementById('diagConfidence');
    const factors = document.getElementById('diagFactors');
    const remediation = document.getElementById('diagRemediation');

    // Severity styling
    const sev = diag.severity || 'HEALTHY';
    badge.textContent = sev;
    badge.className = 'px-3 py-1 rounded-full text-xs font-bold tracking-wider uppercase ';
    if (sev === 'CRITICAL') {
        badge.className += 'bg-rose-500/20 text-rose-400 border border-rose-500/40 glow-rose';
    } else if (sev === 'WARNING') {
        badge.className += 'bg-amber-500/20 text-amber-400 border border-amber-500/40 glow-amber';
    } else {
        badge.className += 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 glow-emerald';
    }

    verdict.textContent = diag.verdict || 'OPTIMAL_HEALTHY';
    headline.textContent = diag.headline || 'System Operating Normally';
    summary.textContent = diag.summary || '';
    proof.textContent = diag.mathematical_proof || 'No anomalies detected.';
    confidence.textContent = `${Math.round((diag.confidence_score || 0.95) * 100)}%`;

    // Root-Cause Factors
    if (factors) {
        factors.innerHTML = '';
        if (diag.root_cause_factors && diag.root_cause_factors.length > 0) {
            diag.root_cause_factors.forEach(f => {
                const div = document.createElement('div');
                div.className = 'p-3 bg-slate-900/60 rounded border border-slate-800 text-xs';
                div.innerHTML = `<div class="font-bold text-cyan-400 mb-1">${f.factor}</div><div class="text-slate-300">${f.detail}</div>`;
                factors.appendChild(div);
            });
        } else {
            factors.innerHTML = '<div class="text-xs text-slate-500 italic">No adverse root-cause anomalies identified.</div>';
        }
    }

    // Remediation list
    if (remediation) {
        remediation.innerHTML = '';
        if (diag.remediation_steps && diag.remediation_steps.length > 0) {
            diag.remediation_steps.forEach(r => {
                const li = document.createElement('li');
                li.className = 'flex items-start gap-2 text-xs text-slate-300';
                li.innerHTML = `<span class="text-cyan-400 font-bold">›</span> <span>${r}</span>`;
                remediation.appendChild(li);
            });
        }
    }
}

/**
 * Updates Forensic Evidence Timeline Chain
 */
function updateEvidenceChain(chain) {
    const container = document.getElementById('evidenceTimeline');
    if (!container) return;
    container.innerHTML = '';

    if (!chain || chain.length === 0) {
        container.innerHTML = '<div class="text-xs text-slate-500 italic p-4">No audit milestones logged.</div>';
        return;
    }

    chain.forEach(item => {
        const div = document.createElement('div');
        div.className = 'relative pl-6 pb-4 border-l-2 border-slate-800 last:border-transparent';

        let dotColor = 'bg-cyan-500';
        if (item.badge === 'ANOMALY') dotColor = 'bg-rose-500 glow-rose';
        else if (item.badge === 'WARN') dotColor = 'bg-amber-500';
        else if (item.badge === 'VERDICT') dotColor = 'bg-purple-500 glow-purple';

        div.innerHTML = `
            <div class="absolute -left-[5px] top-0 w-2.5 h-2.5 rounded-full ${dotColor}"></div>
            <div class="flex items-center gap-2 mb-1">
                <span class="text-[10px] font-mono font-bold bg-slate-800 px-1.5 py-0.5 rounded text-slate-400">Frame #${item.packet_index}</span>
                <span class="text-[10px] font-mono text-cyan-400">+${item.rel_time.toFixed(4)}s</span>
                <span class="text-xs font-semibold text-slate-200">${item.event}</span>
            </div>
            <div class="text-xs text-slate-400 leading-relaxed font-mono">${item.details}</div>
        `;
        container.appendChild(div);
    });
}

/**
 * Renders 5-Tuple Demuxed Conversation Sessions Matrix
 */
function renderSessionsTable(sessions) {
    const tbody = document.getElementById('sessionsTableBody');
    if (!tbody) return;
    tbody.innerHTML = '';

    sessions.forEach(s => {
        const tr = document.createElement('tr');
        const isActive = (s.session_id === state.activeSessionId);
        tr.className = `border-b border-slate-800/60 transition cursor-pointer ${isActive ? 'bg-cyan-950/30 border-l-2 border-l-cyan-400' : 'hover:bg-slate-800/40'}`;

        let sevBadge = '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400">HEALTHY</span>';
        if (s.diagnosis_severity === 'CRITICAL') {
            sevBadge = '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/20 text-rose-400">CRITICAL</span>';
        } else if (s.diagnosis_severity === 'WARNING') {
            sevBadge = '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-400">WARNING</span>';
        }

        tr.innerHTML = `
            <td class="p-3 text-xs font-mono font-bold text-cyan-400">${s.proto}</td>
            <td class="p-3 text-xs font-mono text-slate-300">${s.client_ip}:${s.client_port}</td>
            <td class="p-3 text-xs font-mono text-slate-300">${s.server_ip}:${s.server_port}</td>
            <td class="p-3 text-xs font-mono text-right text-slate-300">${s.packet_count}</td>
            <td class="p-3 text-xs font-mono text-right text-slate-300">${formatBytes(s.total_wire_bytes)}</td>
            <td class="p-3 text-xs font-mono text-right text-slate-200 font-semibold">${s.wire_mbps.toFixed(2)}</td>
            <td class="p-3 text-xs font-mono text-right ${s.loss_rate_pct > 0 ? 'text-rose-400 font-bold' : 'text-slate-400'}">${s.loss_rate_pct.toFixed(1)}%</td>
            <td class="p-3 text-xs font-mono text-right text-slate-400">${s.avg_rtt_ms ? s.avg_rtt_ms.toFixed(1) + 'ms' : '-'}</td>
            <td class="p-3 text-center">${sevBadge}</td>
        `;

        tr.addEventListener('click', () => {
            selectSession(s.session_id);
        });

        tbody.appendChild(tr);
    });
}

/**
 * Handles Session selection for drill-down charting and packet filtering
 */
function selectSession(sessionId) {
    state.activeSessionId = sessionId;
    renderSessionsTable(state.analysis.sessions);
    updateChartsForActiveSession();

    // Filter packet table to this session
    state.currentPage = 1;
    filterAndRenderPackets();
}

/**
 * Updates all Chart.js instances based on selected session or global capture
 */
function updateChartsForActiveSession() {
    if (!state.analysis) return;

    let targetDetails = null;
    if (state.activeSessionId && state.analysis.detailed_sessions && state.analysis.detailed_sessions[state.activeSessionId]) {
        targetDetails = state.analysis.detailed_sessions[state.activeSessionId];
    } else {
        const keys = Object.keys(state.analysis.detailed_sessions || {});
        if (keys.length > 0) {
            targetDetails = state.analysis.detailed_sessions[keys[0]];
        }
    }

    if (targetDetails) {
        renderThroughputChart(targetDetails.timeseries_throughput);
        renderTcptraceChart(targetDetails.timeseries_tcptrace);
        renderRttChart(targetDetails.timeseries_rtt);
    }

    renderProtocolChart(state.analysis.protocol_breakdown);
    renderPacketSizeChart(state.analysis.packets);
}

/**
 * Filters packet stream by search query, protocol, and active session
 */
function filterAndRenderPackets() {
    if (!state.analysis || !state.analysis.packets) return;

    let pkts = state.analysis.packets;

    // Session filter
    if (state.activeSessionId) {
        pkts = pkts.filter(p => p.session_id === state.activeSessionId);
    }

    // Protocol filter
    if (state.packetProtoFilter && state.packetProtoFilter !== 'ALL') {
        pkts = pkts.filter(p => (p.app_proto === state.packetProtoFilter || p.transport_proto === state.packetProtoFilter));
    }

    // Search term
    if (state.packetSearchTerm) {
        const term = state.packetSearchTerm;
        pkts = pkts.filter(p =>
            p.src_ip.includes(term) ||
            p.dst_ip.includes(term) ||
            p.info.toLowerCase().includes(term) ||
            p.forensic_tags.some(t => t.toLowerCase().includes(term))
        );
    }

    state.filteredPackets = pkts;
    renderPacketTable();
}

/**
 * Renders paginated packet list in top inspector pane
 */
function renderPacketTable() {
    const tbody = document.getElementById('packetTableBody');
    if (!tbody) return;
    tbody.innerHTML = '';

    const startIdx = (state.currentPage - 1) * state.pageSize;
    const endIdx = startIdx + state.pageSize;
    const pagePackets = state.filteredPackets.slice(startIdx, endIdx);

    // Update pagination labels
    const totalPages = Math.ceil(state.filteredPackets.length / state.pageSize) || 1;
    document.getElementById('pageInfo').textContent = `Page ${state.currentPage} of ${totalPages} (${state.filteredPackets.length} frames)`;

    pagePackets.forEach(p => {
        const tr = document.createElement('tr');
        const isActive = (p.index === state.activePacketIndex);
        tr.className = `packet-row border-b border-slate-800/40 ${isActive ? 'active-row' : ''}`;

        // Tag Pills
        let tagsHtml = '';
        if (p.forensic_tags && p.forensic_tags.length > 0) {
            p.forensic_tags.forEach(t => {
                let tagClass = 'tag-retransmission';
                if (t.includes('Dup ACK')) tagClass = 'tag-dup-ack';
                else if (t.includes('Zero Window')) tagClass = 'tag-zero-win';
                else if (t.includes('Out-of-Order')) tagClass = 'tag-out-of-order';
                tagsHtml += `<span class="px-1.5 py-0.5 rounded text-[9px] font-bold ${tagClass} mr-1">${t}</span>`;
            });
        }

        tr.innerHTML = `
            <td class="p-2 text-[11px] font-mono text-slate-400 text-center">${p.index}</td>
            <td class="p-2 text-[11px] font-mono text-cyan-400">${p.rel_time.toFixed(4)}s</td>
            <td class="p-2 text-[11px] font-mono text-slate-300">${p.src_ip || p.src_mac}</td>
            <td class="p-2 text-[11px] font-mono text-slate-300">${p.dst_ip || p.dst_mac}</td>
            <td class="p-2 text-[11px] font-mono font-semibold text-sky-400">${p.app_proto || p.transport_proto || p.network_proto}</td>
            <td class="p-2 text-[11px] font-mono text-right text-slate-400">${p.wire_len} B</td>
            <td class="p-2 text-[11px] font-mono text-slate-300 truncate max-w-[320px]">
                ${tagsHtml} ${p.info}
            </td>
        `;

        tr.addEventListener('click', () => {
            selectPacket(p.index);
        });

        tbody.appendChild(tr);
    });
}

/**
 * Inspects a single packet: updates decoded protocol tree and hex dump view
 */
function selectPacket(index) {
    state.activePacketIndex = index;
    renderPacketTable();

    const pkt = state.analysis?.packets?.find(p => p.index === index);
    if (!pkt) return;

    // Update Protocol Tree
    renderProtocolTree(pkt);

    // Update Hex Dump
    renderHexDump(pkt);
}

/**
 * Renders Decoded Protocol Layers Tree (Wireshark Middle Pane)
 */
function renderProtocolTree(pkt) {
    const tree = document.getElementById('protocolTree');
    if (!tree) return;
    tree.innerHTML = '';

    const addSection = (title, items, isExpanded = true) => {
        const details = document.createElement('details');
        if (isExpanded) details.open = true;
        details.className = 'mb-2 bg-slate-900/60 rounded border border-slate-800 text-xs font-mono';

        const summary = document.createElement('summary');
        summary.className = 'p-2 font-bold cursor-pointer text-cyan-400 hover:text-cyan-300 select-none bg-slate-800/40 rounded-t';
        summary.textContent = `▶ ${title}`;
        details.appendChild(summary);

        const content = document.createElement('div');
        content.className = 'p-2 space-y-1 text-slate-300';
        items.forEach(it => {
            const row = document.createElement('div');
            row.className = 'flex justify-between py-0.5 border-b border-slate-800/40 last:border-0';
            row.innerHTML = `<span class="text-slate-400">${it.key}:</span> <span class="text-slate-200 font-semibold">${it.val}</span>`;
            content.appendChild(row);
        });
        details.appendChild(content);
        tree.appendChild(details);
    };

    // Frame Layer
    addSection(`Frame #${pkt.index} (${pkt.wire_len} bytes on wire, ${pkt.cap_len} captured)`, [
        { key: 'Arrival Time (Rel)', val: `+${pkt.rel_time.toFixed(6)} s` },
        { key: 'Wire Length', val: `${pkt.wire_len} bytes` },
        { key: 'Captured Length', val: `${pkt.cap_len} bytes` },
    ]);

    // Ethernet Layer
    if (pkt.src_mac || pkt.dst_mac) {
        addSection(`Ethernet II, Src: ${pkt.src_mac}, Dst: ${pkt.dst_mac}`, [
            { key: 'Source MAC', val: pkt.src_mac },
            { key: 'Destination MAC', val: pkt.dst_mac },
            { key: 'EtherType', val: pkt.network_proto },
        ]);
    }

    // IP Layer
    if (pkt.src_ip && pkt.dst_ip) {
        addSection(`Internet Protocol (${pkt.network_proto}), Src: ${pkt.src_ip}, Dst: ${pkt.dst_ip}`, [
            { key: 'Source IP', val: pkt.src_ip },
            { key: 'Destination IP', val: pkt.dst_ip },
            { key: 'Time to Live (TTL)', val: pkt.ip_ttl },
            { key: 'Transport Protocol', val: pkt.transport_proto },
        ]);
    }

    // TCP / UDP Layer
    if (pkt.transport_proto === 'TCP') {
        addSection(`Transmission Control Protocol, Src Port: ${pkt.src_port}, Dst Port: ${pkt.dst_port}`, [
            { key: 'Source Port', val: pkt.src_port },
            { key: 'Destination Port', val: pkt.dst_port },
            { key: 'Sequence Number (Raw)', val: pkt.tcp_seq },
            { key: 'Acknowledgment (Raw)', val: pkt.tcp_ack },
            { key: 'Flags', val: pkt.tcp_flags_str },
            { key: 'Advertised Window', val: `${pkt.tcp_win} (Scale: ${pkt.tcp_win_scale ?? 'None'})` },
            { key: 'MSS Option', val: pkt.tcp_mss ?? 'Not specified' },
            { key: 'SACK Permitted', val: pkt.tcp_sack_perm ? 'Yes' : 'No' },
            { key: 'RTT Sample', val: pkt.rtt_sample ? `${pkt.rtt_sample.toFixed(3)} ms` : 'N/A' },
            { key: 'Forensic Tags', val: pkt.forensic_tags.join(', ') || 'Normal segment' },
        ]);
    } else if (pkt.transport_proto === 'UDP') {
        addSection(`User Datagram Protocol, Src Port: ${pkt.src_port}, Dst Port: ${pkt.dst_port}`, [
            { key: 'Source Port', val: pkt.src_port },
            { key: 'Destination Port', val: pkt.dst_port },
            { key: 'Payload Length', val: `${pkt.payload_len} bytes` },
        ]);
    }

    // Payload Layer
    if (pkt.payload_len > 0) {
        addSection(`Application Payload (${pkt.app_proto || 'Data'}, ${pkt.payload_len} bytes)`, [
            { key: 'Payload Bytes', val: `${pkt.payload_len} bytes` },
            { key: 'Application Hint', val: pkt.app_proto },
        ]);
    }
}

/**
 * Renders Hex Dump View (Wireshark Bottom Pane)
 */
function renderHexDump(pkt) {
    const hexContainer = document.getElementById('hexDump');
    if (!hexContainer) return;

    if (!pkt.hexdump || pkt.hexdump.length === 0) {
        hexContainer.innerHTML = '<div class="text-slate-500 italic p-4">No raw frame data available.</div>';
        return;
    }

    hexContainer.innerHTML = pkt.hexdump.map(line => `<div class="hexdump-line py-0.5 px-2 font-mono whitespace-pre">${line}</div>`).join('');
}

/**
 * Helper byte formatters
 */
function formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function showLoading(show) {
    const spinner = document.getElementById('loadingOverlay');
    if (spinner) {
        if (show) spinner.classList.remove('hidden');
        else spinner.classList.add('hidden');
    }
}

// Export functions
function downloadReportMarkdown() {
    window.location.href = '/api/export/markdown';
}

function downloadReportPDF() {
    window.location.href = '/api/export/pdf';
}

function downloadReportJSON() {
    if (!state.analysis) return;
    const blob = new Blob([JSON.stringify(state.analysis, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `forensics_${state.analysis.filename}.json`;
    a.click();
    URL.revokeObjectURL(url);
}
