/**
 * NetForensics Telemetry & Time-Sequence Charts
 * Uses Chart.js with dark-mode canvas rendering.
 */

let throughputChartInstance = null;
let tcptraceChartInstance = null;
let rttChartInstance = null;
let protocolChartInstance = null;
let packetSizeChartInstance = null;

// Global Chart.js Defaults for Dark Mode
if (window.Chart) {
    Chart.defaults.color = '#94a3b8';
    Chart.defaults.borderColor = '#1e293b';
    Chart.defaults.font.family = "'JetBrains Mono', monospace";
}

/**
 * Renders Throughput & Goodput Timeseries Chart
 */
function renderThroughputChart(timeseries) {
    const ctx = document.getElementById('throughputChart');
    if (!ctx) return;

    if (throughputChartInstance) {
        throughputChartInstance.destroy();
    }

    if (!timeseries || timeseries.length === 0) {
        return;
    }

    const labels = timeseries.map(d => `${d.time.toFixed(3)}s`);
    const wireData = timeseries.map(d => d.wire_mbps);
    const goodputData = timeseries.map(d => d.goodput_mbps);
    const ppsData = timeseries.map(d => d.pps);

    throughputChartInstance = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Wire Throughput (Mbps)',
                    data: wireData,
                    borderColor: '#38bdf8',
                    backgroundColor: 'rgba(56, 189, 248, 0.12)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.2,
                    pointRadius: 2,
                    yAxisID: 'y'
                },
                {
                    label: 'Application Goodput (Mbps)',
                    data: goodputData,
                    borderColor: '#10b981',
                    backgroundColor: 'rgba(16, 185, 129, 0.08)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.2,
                    pointRadius: 2,
                    yAxisID: 'y'
                },
                {
                    label: 'Packet Rate (pps)',
                    data: ppsData,
                    borderColor: '#a855f7',
                    borderWidth: 1.5,
                    borderDash: [4, 4],
                    fill: false,
                    pointRadius: 0,
                    yAxisID: 'y1'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                mode: 'index',
                intersect: false,
            },
            plugins: {
                legend: {
                    position: 'top',
                    labels: { boxWidth: 12, font: { size: 11 } }
                },
                tooltip: {
                    backgroundColor: '#0f172a',
                    titleColor: '#f8fafc',
                    bodyColor: '#cbd5e1',
                    borderColor: '#334155',
                    borderWidth: 1,
                    padding: 10
                }
            },
            scales: {
                x: {
                    title: { display: true, text: 'Relative Time (seconds)', color: '#64748b', font: { size: 11 } },
                    grid: { color: 'rgba(51, 65, 85, 0.3)' }
                },
                y: {
                    type: 'linear',
                    display: true,
                    position: 'left',
                    title: { display: true, text: 'Throughput (Mbps)', color: '#38bdf8', font: { size: 11 } },
                    grid: { color: 'rgba(51, 65, 85, 0.3)' },
                    min: 0
                },
                y1: {
                    type: 'linear',
                    display: true,
                    position: 'right',
                    title: { display: true, text: 'Packets / Sec (pps)', color: '#a855f7', font: { size: 11 } },
                    grid: { drawOnChartArea: false },
                    min: 0
                }
            }
        }
    });
}

/**
 * Renders Time-Sequence Graph (tcptrace Style Ladder Graph)
 */
function renderTcptraceChart(tcptraceData) {
    const ctx = document.getElementById('tcptraceChart');
    if (!ctx) return;

    if (tcptraceChartInstance) {
        tcptraceChartInstance.destroy();
    }

    if (!tcptraceData || tcptraceData.length === 0) return;

    // Separate into Data points, ACK line, Retransmissions, Dup ACKs
    const seqPoints = [];
    const ackPoints = [];
    const retransPoints = [];
    const dupAckPoints = [];

    tcptraceData.forEach(d => {
        if (d.len > 0) {
            seqPoints.push({ x: d.time, y: d.seq });
            if (d.is_retrans) {
                retransPoints.push({ x: d.time, y: d.seq });
            }
        }
        if (d.ack !== null && d.ack !== undefined) {
            ackPoints.push({ x: d.time, y: d.ack });
            if (d.is_dup_ack) {
                dupAckPoints.push({ x: d.time, y: d.ack });
            }
        }
    });

    tcptraceChartInstance = new Chart(ctx, {
        type: 'scatter',
        data: {
            datasets: [
                {
                    label: 'Forward Sequence (Data)',
                    data: seqPoints,
                    backgroundColor: '#38bdf8',
                    borderColor: '#0284c7',
                    pointRadius: 3,
                    showLine: false
                },
                {
                    label: 'Reverse Acknowledgment (ACK)',
                    data: ackPoints,
                    borderColor: '#10b981',
                    backgroundColor: '#10b981',
                    borderWidth: 1.5,
                    pointRadius: 2,
                    showLine: true,
                    stepped: true
                },
                {
                    label: 'Retransmission Event',
                    data: retransPoints,
                    backgroundColor: '#f43f5e',
                    borderColor: '#ffffff',
                    borderWidth: 1.5,
                    pointRadius: 6,
                    pointStyle: 'triangle',
                    showLine: false
                },
                {
                    label: 'Duplicate ACK Trigger',
                    data: dupAckPoints,
                    backgroundColor: '#f59e0b',
                    borderColor: '#ffffff',
                    borderWidth: 1.5,
                    pointRadius: 5,
                    pointStyle: 'rectRot',
                    showLine: false
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: { boxWidth: 12, font: { size: 11 } }
                },
                tooltip: {
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    borderWidth: 1,
                    callbacks: {
                        label: function(ctx) {
                            return `${ctx.dataset.label}: Time=${ctx.parsed.x.toFixed(4)}s, Seq/Ack=${ctx.parsed.y}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    type: 'linear',
                    title: { display: true, text: 'Time (s)', color: '#64748b', font: { size: 11 } },
                    grid: { color: 'rgba(51, 65, 85, 0.3)' }
                },
                y: {
                    title: { display: true, text: 'TCP Sequence / ACK Number', color: '#64748b', font: { size: 11 } },
                    grid: { color: 'rgba(51, 65, 85, 0.3)' }
                }
            }
        }
    });
}

/**
 * Renders Latency, RFC 6298 Smoothed RTT, and RTTVAR Dynamics
 */
function renderRttChart(rttData) {
    const ctx = document.getElementById('rttChart');
    if (!ctx) return;

    if (rttChartInstance) {
        rttChartInstance.destroy();
    }

    if (!rttData || rttData.length === 0) return;

    const labels = rttData.map(d => `${d.time.toFixed(3)}s`);
    const rttSamples = rttData.map(d => d.rtt_ms);
    const srttSamples = rttData.map(d => d.srtt_ms);
    const rtoSamples = rttData.map(d => d.rto_ms);

    rttChartInstance = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Sampled RTT (ms)',
                    data: rttSamples,
                    borderColor: '#38bdf8',
                    backgroundColor: 'rgba(56, 189, 248, 0.1)',
                    borderWidth: 1.5,
                    pointRadius: 3,
                    tension: 0.1
                },
                {
                    label: 'RFC 6298 Smoothed RTT (SRTT)',
                    data: srttSamples,
                    borderColor: '#06b6d4',
                    borderWidth: 2.5,
                    pointRadius: 0,
                    tension: 0.2
                },
                {
                    label: 'RTO Threshold (ms)',
                    data: rtoSamples,
                    borderColor: '#f43f5e',
                    borderWidth: 1.5,
                    borderDash: [5, 5],
                    pointRadius: 0,
                    fill: false
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'top', labels: { boxWidth: 12, font: { size: 11 } } },
                tooltip: { backgroundColor: '#0f172a', borderColor: '#334155', borderWidth: 1 }
            },
            scales: {
                x: {
                    title: { display: true, text: 'Time (s)', color: '#64748b', font: { size: 11 } },
                    grid: { color: 'rgba(51, 65, 85, 0.3)' }
                },
                y: {
                    title: { display: true, text: 'Delay / RTT (ms)', color: '#06b6d4', font: { size: 11 } },
                    grid: { color: 'rgba(51, 65, 85, 0.3)' },
                    min: 0
                }
            }
        }
    });
}

/**
 * Renders Protocol Breakdown Doughnut Chart
 */
function renderProtocolChart(protocolData) {
    const ctx = document.getElementById('protocolChart');
    if (!ctx) return;

    if (protocolChartInstance) {
        protocolChartInstance.destroy();
    }

    if (!protocolData || !protocolData.counts) return;

    const labels = Object.keys(protocolData.counts);
    const data = Object.values(protocolData.counts);
    const colors = ['#38bdf8', '#10b981', '#a855f7', '#f59e0b', '#f43f5e', '#64748b'];

    protocolChartInstance = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: colors.slice(0, labels.length),
                borderColor: '#0f172a',
                borderWidth: 2,
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom', labels: { boxWidth: 10, font: { size: 11 } } },
                tooltip: { backgroundColor: '#0f172a', borderColor: '#334155', borderWidth: 1 }
            },
            cutout: '65%'
        }
    });
}

/**
 * Renders Packet Size Distribution Bar Chart
 */
function renderPacketSizeChart(packets) {
    const ctx = document.getElementById('packetSizeChart');
    if (!ctx) return;

    if (packetSizeChartInstance) {
        packetSizeChartInstance.destroy();
    }

    if (!packets || packets.length === 0) return;

    const bins = { '< 64B': 0, '64-128B': 0, '128-512B': 0, '512-1024B': 0, '1024-1514B': 0, '> 1514B (Jumbo)': 0 };

    packets.forEach(p => {
        const sz = p.wire_len;
        if (sz < 64) bins['< 64B']++;
        else if (sz <= 128) bins['64-128B']++;
        else if (sz <= 512) bins['128-512B']++;
        else if (sz <= 1024) bins['512-1024B']++;
        else if (sz <= 1514) bins['1024-1514B']++;
        else bins['> 1514B (Jumbo)']++;
    });

    packetSizeChartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: Object.keys(bins),
            datasets: [{
                label: 'Packet Count',
                data: Object.values(bins),
                backgroundColor: 'rgba(56, 189, 248, 0.7)',
                borderColor: '#38bdf8',
                borderWidth: 1,
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: { backgroundColor: '#0f172a', borderColor: '#334155', borderWidth: 1 }
            },
            scales: {
                x: { grid: { display: false } },
                y: { grid: { color: 'rgba(51, 65, 85, 0.3)' }, min: 0 }
            }
        }
    });
}
