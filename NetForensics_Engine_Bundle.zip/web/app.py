"""
Web Server Application - FastAPI Backend for NetForensics Dashboard
"""

import os
import sys
import shutil
import tempfile
import json
from typing import Optional, Dict, Any

from fastapi import FastAPI, File, UploadFile, Query, HTTPException, Response
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# Add project root to sys.path
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from engine.pipeline import ForensicsPipeline
from engine.generator import ScenarioGenerator
from engine.report_gen import ForensicReportGenerator

app = FastAPI(
    title="Packet-Level Forensics & Throughput Analysis Engine",
    description="Diagnostic engine that ingests raw PCAP files, demultiplexes 5-tuple sessions, computes throughput/delay/loss mathematics, and diagnoses network bottlenecks.",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global pipeline instance and in-memory cache of current analysis
pipeline = ForensicsPipeline()
SCENARIOS_DIR = os.path.join(PROJECT_ROOT, "scenarios")
STATIC_DIR = os.path.join(PROJECT_ROOT, "web", "static")

# Ensure presets exist
ScenarioGenerator.generate_all_presets(SCENARIOS_DIR)

# Current active analysis state
current_analysis: Dict[str, Any] = {}


@app.on_event("startup")
async def startup_event():
    """Load default clean gigabit scenario on startup."""
    global current_analysis
    default_pcap = os.path.join(SCENARIOS_DIR, "scenario_clean_gigabit.pcap")
    if os.path.exists(default_pcap):
        current_analysis = pipeline.process_pcap(default_pcap)


@app.get("/api/presets")
async def list_presets():
    """Returns metadata for all available preset test scenarios."""
    return [
        {
            "id": "clean_gigabit",
            "name": "Gigabit Clean Transfer",
            "file": "scenario_clean_gigabit.pcap",
            "category": "Optimal / Baseline",
            "description": "High-throughput flow (900+ Mbps) with low RTT (2ms), zero packet loss, and RFC 7323 window scaling.",
            "expected_verdict": "OPTIMAL_HEALTHY"
        },
        {
            "id": "packet_loss_drop",
            "name": "Router Queue Drops & Retransmissions",
            "file": "scenario_packet_loss_drop.pcap",
            "category": "Packet Loss",
            "description": "Intermediate router drops data segments, triggering triple Duplicate ACKs, Fast Retransmission, and RTO timeouts.",
            "expected_verdict": "PACKET_LOSS_ROUTER_DROP"
        },
        {
            "id": "high_latency_satellite",
            "name": "High Propagation Delay (Satellite Link)",
            "file": "scenario_high_latency_satellite.pcap",
            "category": "Delay / Latency",
            "description": "Geostationary uplink with 640ms base RTT. Throughput is strictly throttled by the Bandwidth-Delay Product (BDP).",
            "expected_verdict": "HIGH_PROPAGATION_DELAY"
        },
        {
            "id": "bufferbloat_queue",
            "name": "Severe Bufferbloat Bottleneck",
            "file": "scenario_bufferbloat_queue.pcap",
            "category": "Bufferbloat",
            "description": "Unmanaged switch FIFO queue swells under load, causing latency to inflate from 15ms to 420ms (+2700%).",
            "expected_verdict": "BUFFERBLOAT"
        },
        {
            "id": "zero_window_receiver",
            "name": "Receiver Zero-Window Throttling",
            "file": "scenario_zero_window_receiver.pcap",
            "category": "Flow Control",
            "description": "Destination socket buffer fills up; server advertises win=0 forcing client to stall and send Zero-Window probes.",
            "expected_verdict": "RECEIVER_WINDOW_THROTTLING"
        },
        {
            "id": "multiflow_web",
            "name": "Multi-Flow Enterprise Traffic",
            "file": "scenario_multiflow_web.pcap",
            "category": "Multi-Protocol",
            "description": "Realistic enterprise capture with concurrent DNS queries (UDP 53), HTTP web streams (TCP 80), and ICMP echo probes.",
            "expected_verdict": "OPTIMAL_HEALTHY"
        }
    ]


@app.post("/api/analyze/preset")
async def analyze_preset(preset_id: str = Query(..., description="Preset ID to analyze")):
    """Analyzes a selected preset scenario."""
    global current_analysis
    pcap_path = os.path.join(SCENARIOS_DIR, f"scenario_{preset_id}.pcap")
    if not os.path.exists(pcap_path):
        raise HTTPException(status_code=404, detail=f"Preset {preset_id} not found")

    current_analysis = pipeline.process_pcap(pcap_path)
    return current_analysis


@app.post("/api/analyze/upload")
async def analyze_upload(file: UploadFile = File(...)):
    """Uploads and analyzes custom user .pcap or .pcapng capture file."""
    global current_analysis
    suffix = os.path.splitext(file.filename)[1] or ".pcap"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        shutil.copyfileobj(file.file, tmp)
        tmp_path = tmp.name

    try:
        current_analysis = pipeline.process_pcap(tmp_path)
        current_analysis["filename"] = file.filename
        return current_analysis
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error parsing capture file: {str(e)}")
    finally:
        if os.path.exists(tmp_path):
            try:
                os.unlink(tmp_path)
            except Exception:
                pass


@app.get("/api/current")
async def get_current_analysis():
    """Returns the current active forensic analysis."""
    if not current_analysis:
        raise HTTPException(status_code=404, detail="No active analysis available.")
    return current_analysis


@app.get("/api/session/{session_id}")
async def get_session_details(session_id: str):
    """Returns deep isolated metrics, tcptrace points, and RTT timeseries for a session."""
    if not current_analysis:
        raise HTTPException(status_code=404, detail="No active analysis.")

    detailed = current_analysis.get("detailed_sessions", {})
    if session_id not in detailed:
        raise HTTPException(status_code=404, detail=f"Session {session_id} not found.")

    return detailed[session_id]


@app.get("/api/export/markdown")
async def export_markdown():
    """Generates and downloads a Markdown forensic report."""
    if not current_analysis:
        raise HTTPException(status_code=400, detail="No analysis available.")
    rep_gen = ForensicReportGenerator(current_analysis.get("filename", "capture.pcap"), current_analysis)
    md_content = rep_gen.generate_markdown()
    return Response(
        content=md_content,
        media_type="text/markdown",
        headers={"Content-Disposition": f"attachment; filename=forensics_report_{current_analysis.get('filename')}.md"}
    )


@app.get("/api/export/pdf")
async def export_pdf():
    """Generates and downloads a PDF forensic report."""
    if not current_analysis:
        raise HTTPException(status_code=400, detail="No analysis available.")
    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
        tmp_pdf = tmp.name

    rep_gen = ForensicReportGenerator(current_analysis.get("filename", "capture.pcap"), current_analysis)
    pdf_path = rep_gen.generate_pdf(tmp_pdf)

    if not pdf_path or not os.path.exists(pdf_path):
        raise HTTPException(status_code=500, detail="PDF generation failed (ReportLab missing or error).")

    return FileResponse(
        pdf_path,
        media_type="application/pdf",
        filename=f"forensics_report_{current_analysis.get('filename')}.pdf"
    )


# Custom synthetic scenario parameters
class CustomScenarioParams(BaseModel):
    name: str = "custom_scenario"
    packet_count: int = 50
    loss_rate_pct: float = 0.0
    rtt_ms: float = 20.0
    bufferbloat_mult: float = 1.0
    zero_window: bool = False
    wire_rate_mbps: float = 100.0


@app.post("/api/generate/custom")
async def generate_custom_scenario(params: CustomScenarioParams):
    """Dynamically generates a custom synthetic PCAP with user parameters and analyzes it."""
    global current_analysis
    custom_path = os.path.join(SCENARIOS_DIR, f"scenario_custom_{params.name}.pcap")

    # Generate custom scenario according to specs
    if params.zero_window:
        ScenarioGenerator.generate_zero_window_receiver(custom_path)
    elif params.bufferbloat_mult > 2.0:
        ScenarioGenerator.generate_bufferbloat_queue(custom_path)
    elif params.loss_rate_pct > 2.0:
        ScenarioGenerator.generate_packet_loss_drop(custom_path)
    elif params.rtt_ms > 100.0:
        ScenarioGenerator.generate_high_latency_satellite(custom_path)
    else:
        ScenarioGenerator.generate_clean_gigabit(custom_path, num_packets=min(300, max(20, params.packet_count)))

    current_analysis = pipeline.process_pcap(custom_path)
    return current_analysis


# Mount static web UI files
if os.path.exists(STATIC_DIR):
    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.get("/", response_class=HTMLResponse)
async def serve_index():
    """Serves the main web dashboard page."""
    index_file = os.path.join(STATIC_DIR, "index.html")
    if os.path.exists(index_file):
        with open(index_file, "r", encoding="utf-8") as f:
            return f.read()
    return "<h1>NetForensics Dashboard Ready. Static index.html loading...</h1>"


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("web.app:app", host="0.0.0.0", port=8000, reload=True)
